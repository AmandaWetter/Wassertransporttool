<?php

/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 * 
 * Description: Webservice to delete the temporary leitung and pumpe from the database.
 */

session_start();

require_once("../common/WGWFeatureToolExt.inc.php");

try {
    $leitungUID = $_SESSION["leitungUID"];

    if ($leitungUID == null) {
        return;
    }
    
    // GET the database connection
    $oGSIFeature = new GSIFeatureToolExt();
    $dbConnection = $oGSIFeature->_awlconn;

    
    // REMOVE OLD LEITUNG
    /*
    $sqlRemoveLeitung = "DELETE FROM webservice_map.leitung
                WHERE wtp_id = $leitungUID"; */
    
    $sqlRemoveLeitung = "DELETE FROM webservice_map.wt_leitung";
    
    pg_query($dbConnection, $sqlRemoveLeitung);
    
    // REMOVE OLD PUMPE
    /*
    $sqlRemovePumpe = "DELETE FROM webservice_map.pumpe
                WHERE wtp_id = $leitungUID"; */
    
    // REMOVE OLD PUMPE
    $sqlRemovePumpe = "DELETE FROM webservice_map.wt_pumpe";
    
    pg_query($dbConnection, $sqlRemovePumpe);
    
    // Remove global session leitung id
    unset($_SESSION['leitungUID']);
    
    // Send response
    $responseObj = new stdClass();
    $responseObj->message = "Die Daten wurden erfolgreich gespeichert.";
    $responseObj->error = false;

    $response = json_encode($responseObj);
    
    echo $response;
    
} catch (Exception $ex) {

    unset($_SESSION['leitungUID']);
    $responseObj = new stdClass();
    $responseObj->message = $ex->getMessage();
    $responseObj->error = true;

    $response = json_encode($responseObj);

    echo $response;
}


