<?php

/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 * 
 * Description: Delete leitung and pumpe from the "productive" tables.
 */

session_start();

require_once("../common/WGWFeatureToolExt.inc.php");

try {
    
    // GET the database connection
    $oGSIFeature = new GSIFeatureToolExt();
    $dbConnection = $oGSIFeature->_awlconn;
    
    $existingLeitungId = $_POST["leitungId"];
    if($existingLeitungId) {
        // DELETE EXISTING LEITUNG
        $sqlDeleteLeitung = "DELETE FROM feuerwehr.wt_leitung WHERE wtp_id = $existingLeitungId";
        pg_query($dbConnection, $sqlDeleteLeitung);
        
        // DELETE EXISTING PUMPE
        $sqlDeletePumpe = "DELETE FROM feuerwehr.wt_pumpe WHERE wtp_id = $existingLeitungId";
        pg_query($dbConnection, $sqlDeletePumpe);
    }  
    
    // Remove global session leitung id
    unset($_SESSION['leitungUID']);
    
    // Send response
    $responseObj = new stdClass();
    $responseObj->message = "Die Daten wurden erfolgreich gelöscht.";
    $responseObj->error = false;
    $responseObj->leitungUID = $leitungUID;

    $response = json_encode($responseObj);
    
    echo $response;
    
} catch (Exception $ex) {

    unset($_SESSION['leitungUID']);
    $responseObj = new stdClass();
    $responseObj->message = $ex->getMessage();
    $responseObj->error = true;

    $response = json_encode($responseObj);

    echo $response;
}


