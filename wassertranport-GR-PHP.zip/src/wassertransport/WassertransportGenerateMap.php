<?php

/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 */
session_start();
header('Content-Type: text/html; charset=utf-8');

require_once("WassertransportMakeMap.php");
require_once("../_config_global/server_url_config.php" );

//====================================================================
// Input Parameter
//====================================================================
$inNrCoord = $_GET['NRCOORD'];
$inCoord = $_GET['COORD'];
$inTheme = $_GET['THEME'];
$wassermenge = $_GET['wassermenge'];
$schlauchleitung = $_GET['schlauchleitung'];
$max_laenge = $_GET['max_length'];
$max_druck = $_GET['max_druck'];
$start_druck = $_GET['start_druck'];
$becken_freq = $_GET['becken_freq'];
$ersteller = $_GET['ersteller'];
$isUpdate = $_GET['UPDATE'];
$originalMaxLength = $_GET['original_max_length'];



// GR: Parameter bei Bedarf anpassen
$Width = 600;
$Height = 400;
$expfaktor = 1.5;
$minScale = 500; // 1:500
//====================================================================
// Karte erstellen
//====================================================================
$MakeMap = new WassertransportMakeMap($inNrCoord, $inCoord, $inTheme, $Width, $Height, $expfaktor, $minScale, $wassermenge, $schlauchleitung, $max_laenge, $originalMaxLength,$max_druck, $start_druck, $becken_freq, $ersteller);
$mon_image = $MakeMap->imagePath;
$leitungUID = $MakeMap->UID;
$shorterLeitung = $MakeMap->shorterLeitung;

$_SESSION["leitungUID"] = $leitungUID;

// GR: (Relativer) Url Pfad anpassen
$MapName = "/mapfish_tempo/webservice_map/";
$MapName .= end(explode("/", $mon_image));

//====================================================================
// URL für das Profiltool erstellen
//====================================================================
// GR: Url anpassen

$newUrl = $host_ws."/webservices/wassertransport/WassertransportToolResult.phtml?POLY_COUNT="; // GISZ
//$newUrl = "http://192.168.1.62/webservices/wassertransport/WassertransportToolResult.phtml?POLY_COUNT="; // WGW
$newUrl .= $inNrCoord;
$newUrl .= "&coords=";
$newUrl .= $inCoord;
$newUrl .= "&mapname=";
$newUrl .= $MapName;
$newUrl .= "&uid=";
$newUrl .= $leitungUID;
$newUrl .= "&shorterleitung=";
$newUrl .= $shorterLeitung;
$newUrl .= "&update=";
$newUrl .= $isUpdate;

// print $newUrl;
header("Location: $newUrl");
?>
