<?php
/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 * 
 * Description: Generate the profile part with the details informations.
 */
// include Files --------------------------------------------------
require_once("../common/WGWXMLParser.php");
require_once("../common/WGWFeatureToolExt.inc.php");

//-----------------------------------------------------------------


class _cls_TemplateResult {

    /**
     * Chemin du fichier xml
     * @var text
     * @access private
     */
    var $_xmlFile;

    /**
     * Le parser
     * @var variant
     * @access private
     */
    var $_oGSIParser;

    /**
     * La connection a la base
     * @var variant
     * @access private
     */
    var $_oGSIFeature;

    /**
     * le groupe selection
     * @var aray
     * @access private
     */
    var $_aSelectedGroup;

    /**
     * le groupe resultat
     * @var array 
     * @access private
     */
    var $_aResultatGroup;

    /**
     * le X
     * @var double 
     * @access private
     */
    var $_nX;

    /**
     * le Y
     * @var double 
     * @access private
     */
    var $_nY;

    /**
     * la geometrie d'un polygone
     * @var text
     * @access private
     */
    var $_nGeoPoly;

    /**
     * the selected feature (only if featureProfilTool)
     * @var text
     * @access private
     */
    var $_selectedFeature;

    /**
     * le choix du DTM (DTM2 ou DTM25)
     * @var text
     * @access private
     */
    var $_nDTM;

    /**
     * le id de la selection
     * @var double
     * @access private
     */
    var $_nGid;

    /**
     * (relative) url path to map image (created by WGWmakeMap.php)
     * @var text
     * @access private
     */
    var $_mapname;

    //constructeur
    function _cls_TemplateResult($xmlFileTmp, $nX, $nY, $GeoPoly, $DTM = "DTM2", $format = "", $mapname) {


        $xmlFile = $this->findXMLFile($xmlFileTmp);

        if ($xmlFile != "") {
            $this->_xmlFile = $xmlFile;

            $this->_oGSIParser = new GSIParser($xmlFile);
            $this->_oGSIFeature = new GSIFeatureToolExt();

            if (is_int($this->_oGSIParser->GetThemeIndex("Selected"))) {
                $this->_aSelectedGroup = $this->GetResultLayer("Selected", "group_title", "group_field", "group_tocname", "group_dbname", "group_statistic", "group_unit", "group_fieldalias", "group_egrid", "group_mode", "", "group_abstract", "group_fieldabstract");
            }
            if (is_int($this->_oGSIParser->GetThemeIndex("Result"))) {
                $this->_aResultatGroup = $this->GetResultLayer("Result", "", "group_field", "group_tocname", "group_dbname", "group_statistic", "group_unit", "group_fieldalias", "", "group_mode", "group_sort", "group_abstract", "group_fieldabstract");
            }
        }

        $this->_nX = $nX;
        $this->_nY = $nY;
        $this->_nGeoPoly = $GeoPoly;
        $this->_nDTM = $DTM;
        $this->_mapname = $mapname;
    }

    /**
     * @abstract recherche le xmlfile
     * @author jck
     */
    function findXMLFile($xmlFile) {

        $xmlFile = "config/" . $xmlFile . ".xml";

        if (file_exists($xmlFile)) {
            return $xmlFile;
        } else {
            return "";
        }
    }

    /**
     * @abstract downloads the results from Swisstopo
     * @author pma
     */
    function getSwisstopoProfile($format) {
        $url = $this->getProfileRequestUrl($format);


        if (substr($url, 0, 8) == "https://") {
            // proxy settings
                $arrContextOptions=array(
                    "ssl"=>array(
                        "verify_peer"=>false,
                        "verify_peer_name"=>false,
                ),
                "http" => array(
                    "proxy" => "tcp://proxy10.gr.ch:9090",
                    "request_fulluri" => true,
                ),
            );  

            // getting profile through proxy
            $profile = @file_get_contents($url, false, stream_context_create($arrContextOptions));
            $profile = preg_replace('/\n$/','',$profile); 

            // checking content returned
            if ($format == "json" && substr($profile, 0, 1) == '[') {
                return $profile;
            } elseif ($format == "csv" && substr($profile, 0, 15) == '"Distance";"DTM') {
                return $profile;
            } else {
                return $profile;
                //return $url . "-" . $profile . "URL nicht erreichbar.";
            }
        } else { // in case of an error, returning the error's text
            return $url;
        }
    }

    /**
     * @abstract gets the request url to the Swisstopo service
     * @author pma
     * @param string $format
     */
    function getProfileRequestUrl($format) {
        if ($format == "csv") {
            $type = "csv";
        } else {
            $type = "json";
        }

        $urlGeom = "";

        if (is_array($this->_nGeoPoly)) {
            if (count($this->_nGeoPoly) == 1) { // featureProfilTool (_nGeoPoly contains the coords of the point where the user clicked on the map)
                // doing the spatial query to retrieve the feature around the point
                if (!isset($this->_selectedFeature)) {
                    $this->_selectedFeature = $this->getFeature($this->_nGeoPoly);
                }
                if ($this->_selectedFeature != false) {
                    if (isset($this->_selectedFeature['wkt_geom'])) {
                        $linestring = $this->_selectedFeature['wkt_geom'];
                        $urlGeom = $this->getUrlGeom($this->linestring2Coords($linestring));
                    } else {
                        $error = $this->_selectedFeature['error'];
                    }
                }
            } else { // profilTool (_nGeoPoly contains the coords of the line digitalized by the user)
                // constructing the geom string from given coordinates
                $urlGeom = $this->getUrlGeom($this->_nGeoPoly);
            }
        }

        if (substr($urlGeom, 0, 6) == "geom={") {
            // set the parameters and merge them into the final request URL
            $geoservice['url'] = "https://api3.geo.admin.ch/rest/services/profile." . $type . "?";
            $geoservice['geom'] = $urlGeom; // GeoJSON representation of the polyline (type = LineString)
            $geoservice['elevation_models'] = "&elevation_models=" . $this->_nDTM; // comma separated list of elevation models. Two elevation models are available DTM25 and DTM2 (swissALTI3D). Default: DTM25
            $geoservice['nb_points'] = "&nb_points=200"; // number of points used for the polyline segmentization. Default: 200
            $geoservice['cb'] = ""; // the name of the callback funtion
            $geoservice['douglaspeuckerepsilon'] = ""; // epsilon value (float) in meters used for the usage of the Douglas Peucker algorithm 

            return implode("", $geoservice);
        } elseif (isset($error)) { // in case of an error, returning the error's text
            return $error;
        } else { // no geometry returned
            return false;
        }
    }

    function multilinestring2Linestrings($multilinestring) {
        $linestrings = explode("),", substr($multilinestring, 16, -1));

        foreach ($linestrings as $key => $value) { // removing parentheses
            $linestrings[$key] = str_replace("(", "", $linestrings[$key]);
            $linestrings[$key] = str_replace(")", "", $linestrings[$key]);

            $linestrings[$key] = "LINESTRING(" . $linestrings[$key] . ")";
        }

        return $linestrings;
    }

    function linestring2Coords($linestring) {
        $coords = explode(",", substr($linestring, 11, -1));

        return $coords;
    }

    function coords2Linestring($coords) {
        $linestring = "LINESTRING(";
        $linestring .= implode(",", $coords);
        $linestring .= ")";

        return $linestring;
    }

    function getUrlGeom($coords) {
        $urlGeom = "geom={%22type%22%3A%22LineString%22%2C%22coordinates%22%3A[";
        $prefix = "";
        foreach ($coords as $coord_pair) {
            $coord = explode(" ", $coord_pair);
            $x = round($coord[0], 0);
            $y = round($coord[1], 0);
            $urlGeom .= $prefix . "[" . $x . "%2C" . $y . "]";
            $prefix = "%2C";
        }
        $urlGeom .= "]}";

        return $urlGeom;
    }  

    /**
     * @abstract 
     * @author jcke
     */
    function afficheMaskPolyResult() {
        // loop pour chaque layer
        foreach ($this->_aResultatGroup as $szname) {
            $layername = $szname['dbname'];
            $tocname = $szname['tocname'];
            $layerFeld = $szname['attribut'];
            $layerType = $szname['type'];
            $layerStat = $szname['statistic'];
            $fieldalias = $szname['fieldalias'];
            $primary_key_res = $szname['identify'];
            $geometry_column_res = $szname['geocolname'];
            $mode = $szname['mode'];
            $primary_key_sel = $this->_aSelectedGroup[1]['identify'];
            $geometry_column_sel = $this->_aSelectedGroup[1]['geocolname'];

            if ($mode == "individual") { // si le mode individuel est active, on ne prend pas en compte les stats
                $layerStat = "";
            }

            echo $this->makeTable(4, $this->_aSelectedGroup[1]['dbname'], $layername, $tocname, $layerFeld, $layerType, $layerStat, $fieldalias, $primary_key_sel, $geometry_column_sel, $primary_key_res, $geometry_column_res, $mode);
        }
    }
    
    /**
     * Get the details of the pumps for this leitung
     * @param type $UID
     * @return type
     */
    function getPumpeDetails($UID) {
        
        $this->_oGSIFeature = new GSIFeatureToolExt();
        
        $sqlQuery = "SELECT *, ST_X(wkb_geometry), ST_Y(wkb_geometry) FROM webservice_map.wt_pumpe WHERE wtp_id = $UID";
        
        $queryResult = pg_query($this->_oGSIFeature->_awlconn, $sqlQuery);
        
        return $queryResult;
    }
    
    /**
     * Get the number of pumps on this leitung (typ 1 = standart Pumpe; typ 4 = Becken/Pumpe)
     * Modified: 21.02.2022
     * @param type $UID
     * @return type
     */
    function getNumberPumpe($UID) {
        $sqlQuery = "SELECT COUNT(*) FROM webservice_map.wt_pumpe WHERE wtp_id = $UID AND typ IN (1,4)";
        
        $queryResult = pg_query($this->_oGSIFeature->_awlconn, $sqlQuery);
        
        $row = pg_fetch_assoc($queryResult);
        return $row['count'];                
    }
    
    /**
     * Check if this leitung has backen (except the final one)
     * @param type $UID
     * @return boolean
     */
    function hasBacken($UID) {
        $sqlQuery = "SELECT * FROM webservice_map.wt_pumpe WHERE wtp_id = $UID AND typ = 3 order by pumpe_nr";
        
        $queryResult = pg_query($this->_oGSIFeature->_awlconn, $sqlQuery);
        
        if (pg_num_rows($queryResult) > 1) {
            return true;
        }               
        return false;
    }
    
    /**
     * Get the max druck
     * @param type $UID
     * @return type
     */
    function getMaxDruck($UID) {
        $sqlQuery = "SELECT MAX(a_bar) FROM webservice_map.wt_pumpe WHERE wtp_id = $UID AND typ IN (1,4)";
        
        $queryResult = pg_query($this->_oGSIFeature->_awlconn, $sqlQuery);
        
        $row = pg_fetch_assoc($queryResult);
        return $row['max'];     
    }
    
    /**
     * Get the end druck of the leitung.
     * @param type $UID
     * @return type
     */
    function getEndDruck($UID) {
        $sqlQuery = "SELECT e_bar FROM webservice_map.wt_pumpe WHERE wtp_id = $UID AND typ = 3";
        
        $queryResult = pg_query($this->_oGSIFeature->_awlconn, $sqlQuery);
        
        $row = pg_fetch_assoc($queryResult);
        return $row['e_bar']; 
    }
    
    /**
     * Get details on all segment of this line
     * @param type $UID
     * @return type
     */
    function getLeitungDetails($UID) {
        $sqlQuery = "SELECT * FROM webservice_map.wt_leitung WHERE wtp_id = $UID";
        
        $queryResult = pg_query($this->_oGSIFeature->_awlconn, $sqlQuery);
        
        return $queryResult;
    }

    /**
     * @abstract affichage du contenu de la popup pour les widgets GSIProfilTool et GSIFeatureProfilTool
     * @author pma
     */
    function displayProfileMask($leitungUID, $shorterLeitung, $update) {

        // detecting mode (featureProfilTool / profilTool)
        $featureProfil = "false";
        if (is_array($this->_nGeoPoly)) {
            if (count($this->_nGeoPoly) == 1) {
                $featureProfil = "true";
            } else {
                $featureProfil = "false";
            }
        }

        // if an intersection layer has been configured, executing the intersection with the profile
        if (is_array($this->_aResultatGroup)) {
            $sectionsResults = $this->getProfileIntersections();
        }
        
        $pumpeDetails = $this->getPumpeDetails($leitungUID);
        $leitungDetails = $this->getLeitungDetails($leitungUID);
        
        $numberOfPumps = $this->getNumberPumpe($leitungUID);
        $hasBacken = $this->hasBacken($leitungUID);
        $maxDruck = $this->getMaxDruck($leitungUID);
        $endDruck = $this->getEndDruck($leitungUID);
        $optimalMaxDruck = 0.0;
        $optimization = false;
        
        if ($numberOfPumps > 0 && $endDruck > 2.5) {
            $druckReduction = ($endDruck - 2) / $numberOfPumps;
            $optimalMaxDruck = $maxDruck - $druckReduction;
            $optimization = true;
        }
        
        $numberPumpe = 0;
        $numberBecken = 0;
        $numberHydrant = 0;
        $numberBeckenPumpe = 0;
        $leitungLength = 0;
        $schlauchLeitung = "";

        $schlauchInhalt = 0;
        $schlauchFuellZeit = 0;
        ?>

        <div id="chartOverlay" style="background:#FFF;opacity:0.0;filter:alpha(opacity=0);z-index:99999;position:absolute;top:185px;left:120px;width:550px;height:210px;"></div>
        <input type='hidden' name='featureProfil' value='<?php echo $featureProfil; ?>' />
        <?php if ($optimization && !$hasBacken): ?>
            <div id="optimization" style="font-weight: bold; color: red; float: left;">
                Reduktion Maxdruck auf <?= round($optimalMaxDruck, 1) + 0.1 ?>
            </div>
        <?php endif; ?>
        <?php if ($shorterLeitung && !$update): ?> 
            <div id="shorter-" style="font-weight: bold; color: red; float: right;">
                Max. Transportl&auml;nge erreicht.
        </div>
        <?php endif; ?>
        <table id="layout" cellspacing="10" cellpadding="1" border="0">
            <tbody>
                <tr>
                    <td class="layoutTable">
                        <table class="titleArea" width="680px" cellspacing="0" cellpadding="4" border="0">
                            <tbody>
                                <tr>
                                    <td>
                                        <span class="title">Wassertransport</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="contentArea" width="680px" cellspacing="0" cellpadding="4" border="0">
                            <tbody>
                                <tr>
                                    <td class="subContentArea1">
                                        <div style="width:99.7%;border:solid 1px rgb(100,100,100);background-color:white;"><p style="margin:0px;margin-left:5px;margin-right:5px;padding-top:3px;padding-bottom:3px;font-size:0.6em;color:rgb(100,100,100);">Hinsichtlich der inhaltlichen Richtigkeit, Genauigkeit, Aktualit&auml;t und Vollst&auml;ndigkeit der ver&ouml;ffentlichten Informationen kann keine Gew&auml;hrleistung &uuml;bernommen werden.</p></div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="LayoutTable" width="680px" cellspacing="0" cellpadding="4" border="0">
                            <tbody>
                                <tr>
                                    <td width="680px" class="subContentArea1" colspan="14">
                                        <div style="width:670px;font-size:0.8em;">
                                            <div id="dbInfos" style="display:none;float:left;min-width:230px;max-width:400px;margin-top:3px;">
                                                <table class="detailsTable" style="min-width:220px;">
                                                    <tr class="featureInfos"><td class="descr">Profillayer</td><td id="profile_layer_abstract" class="value"></td></tr>
                                                    <tr class="featureInfos"><td class="descr">Profilspur</td><td id="feature_descr" class="value"></td></tr>
                                                    <tr id="verschnittLayer"><td class="descr">Verschnittlayer</td><td id="verschnitt_layer_abstract" class="value"></td></tr>
                                                </table>
                                            </div>
                                            <div style="float:right;width:230px;text-align:right;">
                                                <table class="detailsTable">
                                                    <tr>
                                                        <td class="descr" style="text-align:left;">Aufl&ouml;sung &auml;ndern</td>
                                                        <td class="value">
                                                            <form id="radioButtons" method="post" action="" style="margin:0px;margin-bottom:3px;"> 
                                                            <input id="dtm2" class="dtm" type="radio" name="dtm" value="2" <?php
                                                                if ($this->_nDTM == "DTM2") {
                                                                    echo "checked='checked'";
                                                                }
                                                                ?> /><label for="dtm2">2m</label>&nbsp;
                                                                <input id="dtm25" class="dtm" type="radio" name="dtm" value="25" <?php
                                                                if ($this->_nDTM != "DTM2") {
                                                                    echo "checked='checked'";
                                                                }
                                                                ?> /><label for="dtm25">25m</label>
                                                                <input id="details_mem" type="hidden" name="details" value="false" />
                                                            </form>
                                                        </td>
                                                    </tr>
                                                    <tr><td class="descr" style="text-align:left;">&Uuml;berh&ouml;hungsfaktor</td><td id="hfactor" class="value"></td></tr>
                                                    <tr><td class="descr" style="text-align:left;">Datum</td><td class="value"><?php echo date("d.m.Y"); ?></td></tr>
                                                </table>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="680px" class="subContentArea1" colspan="14">
                                        <div id="chart">
                                            <div id='loadingMessage'>Bitte warten...</div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="LayoutTable" width="680px" cellspacing="0" border="0">
                            <tbody>
                                <tr>
                                    <td class="titleArea" colspan="14">
                                        <a id="link" href="#">Details</a>
                                    </td>
                                </tr>
                                <tr id="details">
                                    <td class="subContentArea1" width="100%">
                                        <div style="width:678px;">
                                            <div style="float:left;width:260px;margin-top:10px;margin-bottom:15px;">
                                                <table class="detailsTable">
                                                    <tr><td class="descr">L&auml;nge</td><td id="length" class="value"></td></tr>
                                                    <tr><td class="descr">Maximale H&ouml;he</td><td id="hmax" class="value"></td></tr>
                                                    <tr><td class="descr">Minimale H&ouml;he</td><td id="hmin" class="value"></td></tr>
                                                    <tr><td class="descr">Diskrete Punkte Equidistanz</td><td id="equidistance" class="value"></td></tr>
                                                </table>
                                            </div>
                                            <div style="float:right;width:210px;margin-top:10px;margin-bottom:15px;text-align:right;">
                                                <table class="detailsTable">
                                                    <tr><td class="descr" style="text-align:left;" colspan="2">Koordinaten:</td></tr>
                                                    <tr><td class="descr" style="text-align:left;">Startpunkt</td><td id="coord_start" class="value" width="120"></td></tr>
                                                    <tr><td class="descr" style="text-align:left;">Endepunkt</td><td id="coord_end" class="value" width="120"></td></tr>
                                                </table>
                                                <br />
                                                <a href="http://<?php echo $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>&format=csv<?php
                                                if ($this->_nDTM == "DTM25") {
                                                    echo "&dtm=25";
                                                }
                                                ?>">H&ouml;henprofil Export (CSV)</a>&nbsp;
                                            </div>
                                            <div style="float:left;width:600px;margin-top:10px;margin-bottom:15px;">
                                                Pumpe
                                                <table class="detailsTable">
                                                    <tr>
                                                        <th>Pumpe Nr</th>
                                                        <th>Typ</th>
                                                        <th>Eingangsdruck [bar]</th>
                                                        <th>Ausgangsdruck [bar]</th>
                                                        <th>H&ouml;he &uuml;ber NN [m]</th>
                                                        <th>X</th>
                                                        <th>Y</th>
                                                      </tr>
                                                      <?php while ($row = pg_fetch_assoc($pumpeDetails)): ?>
                                                    
                                                    <tr>
                                                    <td class="value"><?= $row['pumpe_nr'] ?></td>
                                                            <td class="value"><?php
                                                                if ($row['typ'] == 1) {
                                                                    $numberPumpe++;
                                                                    echo "Pumpe";
                                                                } elseif ($row['typ'] == 2) {
                                                                    $numberHydrant++;
                                                                    echo "Hydrant";
                                                                } elseif ($row['typ'] == 3) {
                                                                    $numberBecken++;
                                                                    echo "Becken";
                                                                } elseif ($row['typ'] == 4 || $row['typ'] == 5) {
                                                                    $numberBeckenPumpe++;
                                                                    $numberBecken++;
                                                                    $numberPumpe++;
                                                                    echo "Becken/Pumpe";
                                                                }
                                                                ?></td>
                                                            <td class="value"><?= number_format($row['e_bar'], 1, '.', '') ?></td>
                                                            <td class="value"><?= number_format($row['a_bar'], 1, '.', '') ?></td>
                                                            <td class="value"><?= number_format($row['alt'], 1, '.', '') ?></td>
                                                            <td class="value"><?= number_format($row['st_x'], 0, '.', '') ?></td>
                                                            <td class="value"><?= number_format($row['st_y'], 0, '.', '') ?></td>
                                                    </tr>
                                            
                                            <?php endwhile; ?>
            
                                            </table>
                                            </div>
                                            
                                            <div style="float:left;width:500px;margin-top:10px;margin-bottom:15px;">
                                                Leitung
                                                <table class="detailsTable">
                                                    <tr>
                                                        <th>Leitung Nr</th>
                                                        <th>L&auml;nge [m]</th>
                                                        <th>Wassermenge [l/min]</th>
                                                        <th>H&ouml;henunterschied [m]</th>
                                                        <th>Eingangsdruck [bar]</th>
                                                        <th>Ausgangsdruck [bar]</th>
                                                      </tr>
                                                      <?php while ($row = pg_fetch_assoc($leitungDetails)): ?>
                                                        <?php
                                                        $schlauchLeitung = $row['schlauchleitung_id'];
                                                        $leitungLength += strval($row['laenge']);

                                                        $wasserMaenge = $row['h2o_menge'];
                                                        ?>
                                                        <tr>
                                                            <td class="value"><?= $row['leitun_nr'] ?></td>
                                                            <td class="value"><?= number_format($row['laenge'], 1, '.', '') ?></td>
                                                            <td class="value"><?= $row['h2o_menge'] ?></td>
                                                            <td class="value"><?= number_format($row['dhoehe'], 1, '.', '') ?></td>
                                                            <td class="value"><?= number_format($row['e_bar'], 1, '.', '') ?></td>
                                                            <td class="value"><?= number_format($row['a_bar'], 1, '.', '') ?></td>
                                                    </tr>
                                            
                                            <?php endwhile; ?>
            
                                            </table>
                                            </div>
                                            
                                            <div style="float:left;width:300px;margin-top:10px;margin-bottom:15px;">
                                                Materialliste
                                                <table class="detailsTable">
                                                    
                                                <?php if ($numberPumpe > 0): ?>
                                                    <tr>
                                                        <td class="value"><?= $numberPumpe ?></td>
                                                        <td class="value" style="text-align:left">Pumpen</td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if ($numberBecken > 0): ?>
                                                    <tr>
                                                        <td class="value"><?= $numberBecken ?></td>
                                                        <td class="value" style="text-align:left">Becken</td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <tr>
                                                    <td class="value"><?php
                                                            if (strpos($schlauchLeitung, 'sch_2_') === 0) {
                                                                $leitungLength *= 2;
                                                            }

                                                            echo number_format($leitungLength, 1, '.', '')
                                                            ?>m</td>
                                                        <td class="value" style="text-align:left">Schlauchleitung <?= str_replace("_", "*", str_replace("sch_", "", $schlauchLeitung)) ?>mm</td>
                                                    </tr>
                                                    <tr>
                                                        <?php
                                                        $durchMesser = intval(str_replace("sch_", "", str_replace("sch_2_", "", $schlauchLeitung)));
                                                        $schlauchInhalt = pi() * pow($durchMesser / 1000 / 2, 2) * $leitungLength * 1000;
                                                        $schlauchFuellZeit = $schlauchInhalt / $wasserMaenge;
                                                        ?>
                                                        <td class="value"><?= number_format($schlauchInhalt, 0, '.', "'") ?>l</td>
                                                        <td class="value" style="text-align:left">Schlauchinhalt</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="value">ca. <?= number_format($schlauchFuellZeit, 0, '.', "'") ?> min</td>
                                                        <td class="value" style="text-align:left">Schlauchf&uuml;llzeit</td>
                                                    </tr>
            
                                                <table>
                                            </div>
                                            
                                        </div>
                                    </td>
                                    
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <table width="680px" cellspacing="0" border="0" style="margin-left:10px;">
            <tr>
                <td style="text-align:center;">
                    <img src="<?php echo $this->_mapname; ?>" style="border:0px;" />
                </td>					
            </tr>
            <tr>
                <td style="text-align:right;">
                    <a id="pdf" href="#"><img src="img/acrobatlogo.gif" style="border:0px;" /></a>
                </td>
            </tr>
        </table>

        <script type="text/javascript" src="//www.google.com/jsapi"></script>
        <script type="text/javascript" src="lib/json2.js"></script>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script type="text/javascript" src="lib/jquery.svg.min.js"></script>
        <script type="text/javascript">

            var profileAvailable = false;
            var profileJSON = '<?php echo utf8_decode($this->getSwisstopoProfile("json")); ?>';
            var profileIntersections = <?php
                                                        if (isset($sectionsResults)) {
            echo "JSON.parse('" . json_encode($sectionsResults) . "')";
        } else {
            echo "null";
        }
        ?>;
    var featureProfilMode = $("input[name='featureProfil']").val();
    var featureInfos = <?php
        if (isset($this->_selectedFeature['infos'])) {
            echo "JSON.parse('" . json_encode($this->_selectedFeature['infos']) . "')";
        } else {
            echo "null";
        }
        ?>;
var intersectionsList;

            if (profileIntersections != null) {
                intersectionsList = new Array();

                for (var attributeName in profileIntersections.intersections) { // populating intersectionsList array
                    for (var i = 0; i < profileIntersections.intersections[attributeName].sections.length; i++) {
                        intersectionsList.push({
                            "startpoint": parseFloat(profileIntersections.intersections[attributeName].sections[i].STARTPOINT[0]),
                            "endpoint": parseFloat(profileIntersections.intersections[attributeName].sections[i].ENDPOINT[0]),
                            "attributeName": attributeName
                        });
                    }
                }

                intersectionsList.sort(function (a, b) {
                    return a.startpoint - b.startpoint
                }); // sorting values ascending
            }

            // width / height adjustment to resize the popup suitably for each browser
            var height_adj;
            var width_adj;
            if ($.browser.msie) {
                width_adj = 765;
                height_adj = 100;
            } else {
                width_adj = 740;
                height_adj = 80;
            }

            var basicColors = {
                //aqua: "#00ffff", // cyan
                //azure: "#f0ffff",
                //beige: "#f5f5dc",
                blue: "#0000ff",
                brown: "#a52a2a",
                cyan: "#00ffff",
                //darkblue: "#00008b", // blue
                //darkcyan: "#008b8b", // cyan
                //darkgreen: "#006400", // green
                //darkkhaki: "#bdb76b", //
                //darkmagenta: "#8b008b", // violet
                darkolivegreen: "#556b2f",
                //darkorange: "#ff8c00", // orange
                //darkorchid: "#9932cc", // violet
                darkred: "#8b0000",
                //darksalmon: "#e9967a", //
                //darkviolet: "#9400d3", // violet
                //fuchsia: "#ff00ff", // magenta
                //gold: "#ffd700", //
                green: "#008000",
                indigo: "#4b0082",
                //khaki: "#f0e68c",
                //lightblue: "#add8e6",
                //lightcyan: "#e0ffff",
                lightgreen: "#90ee90",
                //lightgrey: "#d3d3d3",
                //lightpink: "#ffb6c1",
                //lightyellow: "#ffffe0",
                lime: "#00ff00",
                magenta: "#ff00ff",
                black: "#000000",
                //maroon: "#800000", // darkred
                //navy: "#000080", // blue
                olive: "#808000",
                orange: "#ffa500",
                //pink: "#ffc0cb",
                //purple: "#800080", // violet
                violet: "#800080",
                red: "#ff0000",
                darkgrey: "#a9a9a9"
                        //silver: "#c0c0c0",
                        //white: "#ffffff",
                        //yellow: "#ffff00"
            };

            var otherColors = {
                darkkhaki: "#bdb76b",
                darksalmon: "#e9967a",
                gold: "#ffd700",
                aqua: "#00ffff", // cyan
                darkblue: "#00008b", // blue
                darkcyan: "#008b8b",
                darkgreen: "#006400", // green
                darkmagenta: "#8b008b", // violet
                darkorange: "#ff8c00", // orange
                darkorchid: "#9932cc", // violet
                darkviolet: "#9400d3", // violet
                fuchsia: "#ff00ff", // magenta
                lightblue: "#add8e6",
                lightcyan: "#e0ffff",
                lightgrey: "#d3d3d3",
                lightpink: "#ffb6c1",
                lightyellow: "#ffffe0",
                maroon: "#800000", // darkred
                navy: "#000080", // blue
                pink: "#ffc0cb",
                purple: "#800080", // violet
                yellow: "#ffff00"
            };

            $(document).ready(function () {
                var legendHighlightEnabled = true;
                $("#link").click(toggleDetails);

                if ($.browser.msie) {
                    var browserVersion = parseInt($.browser.version);
                    if (browserVersion < 9) { // disable legend highlight for IE < 9 due to printing problems (chart overlay printed with white background)
                        $("#chartOverlay").hide();
                        legendHighlightEnabled = false;
                    }
                }

                if (featureProfilMode == "true" || profileIntersections != null) {
                    $("#dbInfos").show();
                }

                if (featureProfilMode != "true") {
                    $(".featureInfos").hide();
                } else {
                    if (featureInfos != null) {
                        $("#profile_layer_abstract").html(featureInfos.profile_layer_abstract);
                        $("#feature_descr").html(featureInfos.description);
                    }
                }

                if (profileIntersections == null) {
                    $("#verschnittLayer").hide();
                } else {
                    $("#verschnitt_layer_abstract").html(profileIntersections.verschnittLayer);
                }

                // adjusting the window height to fit the layout
                setTimeout(function () {
                    window.resizeTo(width_adj, $(document).height() + height_adj);
                }, 100);

                $(".dtm").change(function () {
                    profileAvailable = false; // avoid deleting selected / digitalized line on map
                    $(this).parent().submit();
                });

                $("#pdf").click(function (e) {
                    e.preventDefault();

                    var title = prompt("Titel der Seite:", $(".title").html());

                    if (title) {
                        $(".title").html(title);
                        window.print();
                    }
                });

                $("#chartOverlay").mousemove(function (e) {
                    if (legendHighlightEnabled == true && intersectionsList != null && $("#errorMessage").length == 0) {
                        var origin;
                        if ($.browser.msie) {
                            origin = 131;
                        } else {
                            origin = 128;
                        }
                        var width = 530;
                        var positionX = e.pageX - origin;
                        var posRatio = positionX / width;

                        if (positionX > 0 && positionX < width) {
                            var value = "Daten nicht vorhanden";
                            for (var i = 0; i < intersectionsList.length; i++) {
                                if (posRatio > intersectionsList[i].startpoint && posRatio < intersectionsList[i].endpoint) {
                                    value = intersectionsList[i].attributeName;

                                    if (value == "") {
                                        value = "null";
                                    }

                                    break;
                                }
                            }

                            $("#legend tr").css("background-color", "white"); // resetting all rows background-color to white
                            $(".legendText:contains('" + value + "')").parents("tr").css("background-color", "rgb(255,230,184)"); // highlighting current row
                        }
                    }
                });

                $("#chartOverlay").mouseout(function (e) {
                    if (legendHighlightEnabled == true) {
                        $("#legend tr").css("background-color", "white");
                    }
                });
            }); 

            $(window).on("beforeunload", function () {
                if (profileAvailable) {
                    if (featureProfilMode == "true") {
                        window.opener.document.getElementsByTagName("form")[0].CLEAR_POINTS.value = "1";
                        window.opener.document.getElementsByTagName("form")[0].NAV_SUBMIT.value = "1";
                        window.opener.document.getElementsByTagName("form")[0].submit();
                    } else {
                        window.opener.goCWCGSIManager.RemoveLast();
                    }
                }
            });

            var showDetails = <?php
                                                        if (isset($_POST['details'])) {
            echo $_POST['details'];
        } else {
            echo "false";
        }
        ?>;
if (showDetails == true) {
                toggleDetails();
            }

            if (profileJSON == false) {
                $("#chart").html("<div id='errorMessage'>Es wurde keine Linie selektiert.</div>");
            } else if (profileJSON.substr(0, 1) == '[') {
                var result = JSON.parse(profileJSON);
                var xUnit = "m";
                var nb_points = result.length - 1;

                google.load("visualization", "1", {packages: ["corechart"]});
                google.setOnLoadCallback(drawChart);
                $("#link").show();
                $("#radioButtons").show();

                if (featureProfilMode == "true") {
                    // reloading parent window to show the line selected, if any
                    window.opener.document.getElementsByTagName("form")[0].submit();
                }
                profileAvailable = true;
            } else if (profileJSON.substr(0, 6) == 'Fehler') {
                $("#chart").html("<div id='errorMessage'>" + profileJSON + "</div>");
            } else {
                $("#chart").html("<div id='errorMessage'>Ein Fehler ist aufgetreten, die Daten der Swisstopo wurden nicht empfangen.</div>");
            }


            function toggleDetails() {
                $("#details").toggle();

                if ($("#details").is(":visible")) {
                    $("#details_mem").attr("value", "true");
                    if (!showDetails) {
                        window.resizeBy(0, 130);
                    }
                } else {
                    $("#details_mem").attr("value", "false");
                    showDetails = false;
                    if (!showDetails) {
                        window.resizeBy(0, -130);
                    }
                }
            }

            function fillInfos(minAlt, maxAlt) {
                var coordStartX = result[0].easting;
                var coordStartY = result[0].northing;
                var coordEndX = result[nb_points].easting;
                var coordEndY = result[nb_points].northing;
                var length = adjustUnit(result[nb_points].dist);
                var equidistance = result[1].dist;

                $("#coord_start").html(coordStartX + " / " + coordStartY);
                $("#coord_end").html(coordEndX + " / " + coordEndY);
                $("#length").html(length + " " + xUnit);
                $("#equidistance").html(equidistance + " m");
                $("#hmax").html(maxAlt + " m");
                $("#hmin").html(minAlt + " m");

                // calculating the elevation factor
                var hRatio = result[nb_points].dist / 530; // 530 is the chart's width in px
                var vRatio = (maxAlt - minAlt) / 130; // 130 is approximately the height of the profile curve in px
                var hFactor = hRatio / vRatio;
                var hFactorRounded;
                if (hFactor < 1) {
                    hFactorRounded = Math.round(hFactor * 10) / 10; // rounding value to 1 decimal place
                } else {
                    hFactorRounded = Math.round(hFactor); // rounding to nearest integer
                }

                $("#hfactor").html("~" + hFactorRounded);
            }

            function drawChart(data) {
                var data = new google.visualization.DataTable();
                data.addColumn('string', 'Distanz');
                data.addColumn('number', '<?php echo utf8_decode("Höhe [m]"); ?>');
                data.addRows(getProfileData());

                var chart = new google.visualization.AreaChart($("#chart").get(0));
                chart.draw(data, {
                    width: 740,
                    height: 280,
                    chartArea: {
                        top: 40
                    },
                    colors: ['#8a3a00'],
                    areaOpacity: 0.5,
                    legend: 'none',
                    hAxis: {
                        title: 'Distanz [' + xUnit + ']'
                    },
                    vAxis: {
                        title: '<?php echo utf8_decode("Höhe [m]"); ?>'
                    }
                });

                if (profileIntersections != null) {
                    extendChart();
                }
            }

            function extendChart() {
                // adding shapes to the original chart to show the intersections with the layer
                var svgRootElement = $("#chart").find("svg:first");
                var svgEdit = svgRootElement.find("g:first").children("g:first").children("g:first")[0];

                if (svgEdit != null) { // the SVG element might not be present, since Google Charts only renders the chart in SVG format on browsers supporting it
                    var svgWrapper = new $.svg._wrapperClass(svgEdit);
                }

                var x = 105;
                var y = 40;
                var width = 530;
                var height = 172;
                var sectionStart = null;
                var sectionEnd = null;
                var sectionWidth = null;
                var color = null;
                var legendItem = null;
                var coverageProportion = 0;

                var n = 0;
                var legend_table = "<table id='legend' cellspacing='5' style='width:520px;margin-left:120px;margin-right:30px;margin-bottom:20px;'></table>";
                $("#chart").after(legend_table);

                var intersections = profileIntersections.intersections;
                for (var attributeName in intersections) {
                    color = null;
                    var result = null;
                    if (attributeName != "LegendHeader") {
                        // assigning a color to the intersection
                        for (var prop in basicColors) {
                            result = prop;
                            color = basicColors[result];
                            delete basicColors[result];
                            break;
                        }
                        if (result == null) {
                            for (var prop2 in otherColors) {
                                result = prop2;
                                color = otherColors[result];
                                delete otherColors[result];
                                break;
                            }
                        }
                    }

                    legendItem = getLegendItem(n, profileIntersections, attributeName, color, svgEdit);
                    $("#legend").append(legendItem);

                    for (var i = 0; i < intersections[attributeName].sections.length; i++) {
                        sectionStart = Math.round(x + (width * parseFloat(intersections[attributeName].sections[i]['STARTPOINT'])));
                        sectionEnd = Math.round(x + (width * parseFloat(intersections[attributeName].sections[i]['ENDPOINT'])));
                        sectionWidth = sectionEnd - sectionStart;
                        coverageProportion += parseFloat(intersections[attributeName].sections[i]['ENDPOINT']) - parseFloat(intersections[attributeName].sections[i]['STARTPOINT']);

                        if (svgEdit != null) { // editing SVG code
                            svgWrapper.rect(sectionStart, y, sectionWidth, height, {fill: color, stroke: 'none', fillOpacity: '0.25'});
                        } else { // editing VML code
                            $("iframe:first").contents().find("#renderers group:first > group:first > div:first > group:first > group:first").append("<v:rect style='POSITION: absolute; WIDTH: " + sectionWidth + "px; HEIGHT: " + height + "px; TOP: " + y + "px; LEFT: " + sectionStart + "px' logicalname='' coordsize = '21600,21600' stroked = 'f'><v:fill on='true' type='solid' opacity='25%' color='" + color + "'/></v:rect>");
                        }
                    }

                    n++;
                }

                if (coverageProportion < 0.999) {
                    // if the profile has sections without intersection, adding an item to the legend with a white sample and "null" as description
                    var nullLegendItem = getLegendItem(n, null, "Daten nicht vorhanden", "white", svgEdit);
                    $("#legend").append(nullLegendItem);
                }
            }

            function getLegendItem(n, profileIntersectionsJSON, attributeName, color, svgEdit) {
                var legendHeaderStyle;
                var legendText;
                if (attributeName == "LegendHeader") {
                    legendHeaderStyle = "font-weight:bold;";
                    legendText = profileIntersectionsJSON.intersections[attributeName].name;
                } else if (attributeName == "") {
                    legendText = "null";
                } else {
                    legendText = attributeName;
                }

                var legendItem = "<tr><td class='sectionType" + n + "' style='clear:both;width:30px;padding-left:5px;padding-right:5px;'><div class='colorSample' style='float:left;width:13px;height:13px;margin:5px;line-height:0em;'>";
                legendItem += getColorSample(svgEdit, color);
                legendItem += "</div></td><td><div class='legendText' style='float:left;font-size:0.8em;line-height:1.2em;" + legendHeaderStyle + "'>" + legendText + "</div></td>";

                if (profileIntersectionsJSON != null) {
                    for (var i = 0; i < profileIntersectionsJSON.visibleSortFields.length; i++) {
                        var sortField = profileIntersectionsJSON.visibleSortFields[i];
                        legendItem += "<td style='font-size:0.8em;" + legendHeaderStyle + "'>" + profileIntersectionsJSON.intersections[attributeName].sortvalues[sortField] + "</td>";
                    }
                }

                legendItem += "</tr>";

                return legendItem;
            }

            function getColorSample(svgEdit, color) {
                // divs background-color are not printed when using window.print() with standard browser properties, so using SVG / VML instead
                var colorSample = "";

                if (color != null) {
                    if (svgEdit != null) {
                        colorSample = "<svg xmlns='http://www.w3.org/2000/svg' version='1.1'><rect width='13' height='13' style='fill:" + color + ";fill-opacity:0.25;stroke-width:1;stroke:rgb(0,0,0)' /></svg>";
                    } else {
                        colorSample = "<v:rect style='position:absolute;width:13px;height:13px;' logicalname='' stroked = 't'><v:fill on='true' type='solid' opacity='25%' color='" + color + "'/></v:rect>";
                    }
                }

                return colorSample;
            }

            function getProfileData() {
                var dist = 0;
                var dist_str = "";
                var alt = 0;
                var minAlt = 9999;
                var maxAlt = 0;
                var div = 1;
                var profileData = new Array();

                for (var i = 0; i < nb_points; i++) {
                    dist = adjustUnit(result[i].dist);
                    dist_str = dist.toString();
                    alt = Math.round(result[i].alts.<?php echo $this->_nDTM; ?> * 10) / 10;
                    if (alt < minAlt)
                        minAlt = alt;
                    if (alt > maxAlt)
                        maxAlt = alt;
                    profileData[i] = [dist_str, alt];
                }

                fillInfos(minAlt, maxAlt);

                return profileData;
            }

            function adjustUnit(value) {
                var length = result[nb_points].dist;
                if (length > 3000) {
                    xUnit = "km";
                    return Math.round(value / 1000 * 10) / 10;
                } else {
                    return Math.round(value);
                }
            }

        </script>
        <?php
    }

    /**
     * @abstract edition du csv de swisstopo (ajout des intersections avec le layer polygone configuré) pour les widgets GSIProfilTool et GSIFeatureProfilTool
     * @author pma
     */
    function displayProfileCsv() {
        $csvProfile = utf8_decode($this->getSwisstopoProfile("csv"));

        if (is_array($this->_aResultatGroup)) { // if an intersection layer has been configured, executing the intersection with the profile
            $sectionsResults = $this->getProfileIntersections();

            $data = explode("\n", $csvProfile);
            $n = count($data) - 2;
            $tmp = explode(";", $data[$n]);
            $length = $tmp[0];

            foreach ($data as $key => $line) {
                $line = trim($line) . ";"; // adding a new column to each line
                $data[$key] = explode(";", $line); // splitting each line into an array
            }
            $data[0][4] = $this->_aResultatGroup[1]['fieldabstract']; // adding new column name to the first line

            if (array_key_exists('intersection', $sectionsResults)) {
                foreach ($sectionsResults['intersections'] as $key => $type) {
                    if ($key != "LegendHeader") {
                        foreach ($type['sections'] as $section) {
                            $min = $length * $section['STARTPOINT'][0];
                            $max = $length * $section['ENDPOINT'][0];

                            for ($i = 1; $i <= $n; $i++) { // adding the attribute value to each line of the csv
                                if ($data[$i][0] >= $min && $data[$i][0] <= $max) {
                                    $data[$i][4] = utf8_decode($key);
                                }
                            }
                        }
                    }
                }
            }

            for ($i = 0; $i <= $n; $i++) { // writing each line of the new csv
                echo implode(";", $data[$i]) . "\n";
            }
        } else {
            echo $csvProfile;
        }
    }

    // fin de la classe
}

/**
 * $Log: GSITemplateResult.php,v $
 *
 * Revision 1.25  2015/08/03 15:54:55  sarah
 * Scripts and xmlFile Path independent from Chameleon
 *
 * Revision 1.24  2015/08/03 15:54:55  nizar
 * modification de l'url du webservice de swisstopo.
 * modification du traitement de la réponse du webservice de swisstopo. 
 * enlevement du paramêtre proxy lors de l'appel du webservice de swisstopo.
 *
 * Revision 1.23  2010/09/03 15:54:55  phanuel
 * fix
 *
 * Revision 1.22  2010/09/02 14:33:36  phanuel
 * modif masque résultat pour Liegenschaft: ajout E-GRID , ne pas afficher" Wert"
 *
 * Revision 1.21  2010/06/23 20:33:35  phanuel
 * changement methode pour connaitre la cle primaire
 *
 * Revision 1.20  2010/06/11 21:04:45  phanuel
 * cle primaire et geometry_column renseignes dynamiquement
 *
 * Revision 1.19  2010/04/30 17:45:48  phanuel
 * Changement de la largeur des colones du subTableArea
 *
 * Revision 1.18  2010/04/30 17:05:06  phanuel
 * Changement de la largeur des colones du subTableArea
 *
 * Revision 1.17  2010/04/30 13:53:27  phanuel
 * Modification de l'affichage de la popup
 *
 * Revision 1.16  2010/04/29 19:13:37  phanuel
 * Modification de la recherche de la cle primaire et du type de champ
 *
 * Revision 1.15  2010/04/28 16:52:35  phanuel
 * Modification de l'affichage de la popup
 *
 * Revision 1.14  2010/03/05 06:10:57  jack
 * - Gestion de la recherche pour les layes line/point
 *
 * Revision 1.13  2010/02/26 10:31:34  jack
 * - Changement fieldname en fieldalias
 *
 * Revision 1.12  2010/02/25 13:34:05  jack
 * - Suppression du label attribut dans le header
 *
 * Revision 1.11  2010/02/25 13:27:15  jack
 * - Suppression de l'espace avant les deux points
 * - Suppression du label Attribut
 *
 * Revision 1.10  2010/02/24 12:46:26  jack
 * - Nom des colonnes
 * - Alignement des colonnes
 *
 * Revision 1.9  2010/02/23 07:48:34  jack
 * - Definition du nom de la colonne avec une entree dans le xmlfile (fieldname)
 *
 * Revision 1.8  2009/11/23 23:09:07  jack
 * - Format et alignement des resultats
 *
 * Revision 1.7  2009/11/23 20:58:34  jack
 * - Alignement des surfaces calculees a droite
 * - Lecture de l'unite de mesure directement a partir du xml
 *
 * Revision 1.6  2009/10/21 20:22:02  jack
 * - Commenter l'affichage de la statistique choisie dans la fonction makeSubTableStat
 *
 * Revision 1.5  2009/10/21 00:48:17  jack
 * - Modification (largeur de colonne) des fonctions makeSubTableStat et makeSubTableArray
 *
 * Revision 1.4  2009/10/20 21:18:10  jack
 * - Somme des aires dans le header du masque GSIFeatureTool
 *
 * Revision 1.3  2009/10/20 18:06:20  jack
 * - Nouveau masque de resultat pour les widgets GSI.
 * - Incorporation du calcul de l'aire et des statistiques
 *
 * Revision 1.2  2009/08/26 21:29:02  jack
 * - Nouvelle gestion du manager
 * - Definition du xmlfile dans la widget
 *
 * Revision 1.1  2009/06/23 20:12:46  jack
 * - Widget de type GSI (GebietSInformation) :
 * - Selection dans une base postgresql depuis un polygone (GSIPolygonTool) ou un point déterminant un Feature d'une table (GSIFeatureTool).
 * 22-06-09
 * jck
 *
 */
?>
