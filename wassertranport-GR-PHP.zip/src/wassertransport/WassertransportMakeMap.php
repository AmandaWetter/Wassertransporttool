<?php

/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 * Description: Generate the map to be displayed when we call the wassertransport service.
 */

header('Content-Type: text/html; charset=utf-8');

require_once("../common/WGWFeatureToolExt.inc.php");
require_once("../common/WGWMapfishConn.inc.php");
require_once("WGWTemplateResult.php");

require_once("../_config_global/func_config.php" );

class WassertransportMakeMap {

    public $imagePath;
    public $UID;
    public $shorterLeitung = false;
    private $wktLine;
    private $dbConnection;
    private $lineLength;
    private $beckenFreq;
    private $ersteller;
    private $maxLaenge;
        
    /**
     * The highest supported pression in tubes
     */
    private $highestDruck = 14;   
    
    

    public function __construct($inNrCoord, $inCoord, $inTheme, $Width, $Height, $expfaktor, $minScale, $wassermenge, $schlauchleitung, $max_laenge, $originalMaxLength, $max_druck, $start_druck, $beckenFreq, $ersteller) {

        require("../_config_global/server_url_config.php" );
        
        // SET the database connection
        $oGSIFeature = new GSIFeatureToolExt();
        $this->dbConnection = $oGSIFeature->_awlconn;
        
        $this->beckenFreq = $beckenFreq;
        
        $this->ersteller = $ersteller ? "'".$ersteller."'" : "null";
        
        $this->maxLaenge = $max_laenge;

        // Get swisstopo Höenprofile
        $coords_tmp = str_replace(",", " ", $inCoord);
        $coords = explode(";", $coords_tmp);

        $TemplateResult = new _cls_TemplateResult("", "", "", $coords, null, "json", "");
        $SwisstopoProfile = utf8_decode($TemplateResult->getSwisstopoProfile("json"));

        // Session ID SID (Zufallszahl)
        $this->UID = mt_rand();
        // GR: Url Anpassen
        // WMS URL für Point, Line, Polygon Layer und Grids
        $WMSUrl = $host_wms."/feuerwehrinformation"; // GISZ
        // $WMSUrl = "http://" . $host . "/wms/wassertransport"; // WGW


        $Offset = 5;
        $CoordXHeight = 25;
        $CoordYWidth = 25;
        $CoordXWidth = $Width;
        $CoordYHeight = $Height;

        $pointarray = explode(";", $inCoord);

        $NrPoints = count($pointarray);

        // Array der Koordinaten
        $points = array();
        foreach ($pointarray as $k => $v) {
            $pointarray[$k] = array_map('floatval', explode(',', $v));
            $temp = explode(',', $v);
            $points[$k]['x'] = floatval($temp[0]);
            $points[$k]['y'] = floatval($temp[1]);
        }

        //(Erster) Punkt
        $xmin = $points[0]['x'];
        $xmax = $points[0]['x'];
        $ymin = $points[0]['y'];
        $ymax = $points[0]['y'];

        //Linie/ Polygon
        if ($NrPoints > 1) {
            $geomStringDB = $points[0]['x'] . " " . $points[0]['y'];
            for ($i = 1; $i < $NrPoints; $i++) {
                $geomStringDB .= "," . $points[$i]['x'] . " " . $points[$i]['y'];
                if ($xmin > $points[$i]['x']) {
                    $xmin = $points[$i]['x'];
                }
                if ($xmax < $points[$i]['x']) {
                    $xmax = $points[$i]['x'];
                }
                if ($ymin > $points[$i]['y']) {
                    $ymin = $points[$i]['y'];
                }
                if ($ymax < $points[$i]['y']) {
                    $ymax = $points[$i]['y'];
                }
            }

            list($x1, $y1, $x2, $y2, $x3, $y3, $x4, $y4) = $this->makeBbox($xmin, $xmax, $ymin, $ymax, $Width, $Height, $expfaktor, $minScale);
        }

        $this->wktLine = $geomStringDB;

        $this->lineLength = $this->getLineHorizontalLength();


        // Get Druckverlust aus der DB Tabelle (Druckverlust Bar/100m)
        $sqlQuery = "SELECT * FROM feuerwehr.wt_druckverlust WHERE wassermenge <= $wassermenge ORDER BY wassermenge DESC LIMIT 1;";

        $resultDruckverlust = pg_query($this->dbConnection, $sqlQuery);

        $row = pg_fetch_assoc($resultDruckverlust);

        // Normalize druckverlust (Bar / 1m)
        $druckverlust = $row[$schlauchleitung] / 100;

        // Loop through profile to get Pumpe points 
        $previousPression = 0.0;
        $previousDistance = 0.0;
        $previous3DDistance = 0.0;
        
        $totalLength3D = 0.0;
                
        $previousAltitude = 0.0;
        $currentPression = $start_druck;
        $deltaAlt = 0.0;

        $pumpNumber = 1;
        $pumpNumberWithoutBecken = 1;
        $swisstopoJsonProfile = json_decode($SwisstopoProfile, true);

        $previousPumpDistance = 0.0;
        $previousPump3DDistance = 0.0; // Reale Leitungslänge
        $previousPumpAltitude = 0.0;

        $previousPumpPression = $start_druck;
        
        // Profilpunkte der Swisstopo
        $numberPoints = count($swisstopoJsonProfile);

        // Loop on each swisstopo profile point
        foreach ($swisstopoJsonProfile as $key => $Point) {
            
            // Höhenwerte
            $altitude = $Point['alts']['DTM2'];
            
            // Distance von Start
            $dist = $Point['dist'];
            
            // $key = index over profile points
            // 10 Set a start Pump if start_druck <=2
            if ($key == 0 && $currentPression <= 2) {
                // set a Pumpe
                $pumpNumber = 1;
                $this->createPumpe($this->UID, $pumpNumber, 1, $currentPression, $max_druck, $altitude, 0);
                $currentPression = $max_druck;
                $previousAltitude = $altitude;

                $previousPumpAltitude = $altitude;

                $previousPumpPression = $max_druck;

                continue;
            } else if ($key == 0) {

                // set a Startpunkt
                $this->createPumpe($this->UID, $pumpNumber, 2, $currentPression, $currentPression, $altitude, 0);

                $previousAltitude = $altitude;
                $previousPumpAltitude = $altitude;
            }    
            
            $deltaAlt = $altitude - $previousAltitude;

            $previousPression = $currentPression;
            
            // 20 Get the real distance from this segment (Pythagore)
            $distance3D = $this->getLineRealLength($dist - $previousDistance, $deltaAlt); 
            
            
            $totalLength3D += $distance3D;
            
            
            
            // Max length reach
            if($totalLength3D >= $this->maxLaenge) {
                
                $pumpNumber++;
                // Create end point
                // $this->createPumpe($this->UID, $pumpNumber, 3, $currentPression, $currentPression, $altitude, $dist);
                $this->createPumpe($this->UID, $pumpNumber, 3, $currentPression, $currentPression, $previousAltitude, $previousDistance);
                // Create end leitung
                $deltaHoehe = $altitude - $previousPumpAltitude;
                //$this->createLeitung($this->UID, $pumpNumberWithoutBecken, $wassermenge, $schlauchleitung, $deltaHoehe, $previousPumpPression, $currentPression, $previousPumpDistance, $dist, $previousPump3DDistance);
                $this->createLeitung($this->UID, $pumpNumberWithoutBecken, $wassermenge, $schlauchleitung, $deltaHoehe, $previousPumpPression, $currentPression, $previousPumpDistance, $previousDistance, $previousPump3DDistance);
                
                if($this->maxLaenge != $originalMaxLength) {
                    $this->shorterLeitung = true;
                }
                    
                
                    
                
                
                break;
            }

                        $previousPump3DDistance += $distance3D;
            
            // Substract pression lost from the current pression
            $totalDruckVerlust = ($distance3D * $druckverlust) + $deltaAlt * 0.1;
            
            $currentPression -= $totalDruckVerlust;

            // 50 control max druck of $this->highestDruck to display a "Becken" on the map     
            if ($currentPression >= $this->highestDruck) {

                $pumpNumber++;
                $pumpNumberWithoutBecken++;

                // Get the position to set the pump mark at
                $segmentLength = $dist - $previousDistance;
                $deltaPressionFrom = $previousPression - $this->highestDruck;
                $deltaPressionTo = $this->highestDruck - $currentPression;
                
                $distanceFromPrevious = $segmentLength * $deltaPressionFrom / ($deltaPressionFrom + $deltaPressionTo);
                $pumpDistance = $previousDistance + $distanceFromPrevious;
                $previousDistance = $pumpDistance;
                
                // 3D
                $distance3DFromPrevious = $distance3D * $deltaPressionFrom / ($deltaPressionFrom + $deltaPressionTo);
                $pump3DDistance = $previous3DDistance + $distance3DFromPrevious;
                $previous3DDistance = $pump3DDistance;
                
                // Get pression lost pumpe to current point
                $segmentDruckVerlust = $totalDruckVerlust * $deltaPressionFrom / ($deltaPressionFrom + $deltaPressionTo);

                $pumpAltitude = $previousAltitude + ($deltaAlt * $deltaPressionFrom / ($deltaPressionFrom + $deltaPressionTo));
                $previousAltitude = $pumpAltitude;

                $currentPression = 2.1 - $segmentDruckVerlust;              
                

                // Create Backen/Pumpe Ab
                $this->createPumpe($this->UID, $pumpNumber, 5, $this->highestDruck, 2.1, $pumpAltitude, $pumpDistance);
                
                // Save the leitung
                $deltaHoehe = $pumpAltitude - $previousPumpAltitude;
                $this->createLeitung($this->UID, $pumpNumberWithoutBecken - 1, $wassermenge, $schlauchleitung, $deltaHoehe, $previousPumpPression, $this->highestDruck, $previousPumpDistance, $pumpDistance, $previousPump3DDistance);

                $previousPumpPression = 2.1;

                $previousPumpDistance = $pumpDistance;
                $previousPumpAltitude = $pumpAltitude;
                
                $previousPump3DDistance = 0.0;
            }
            // 40 Pression is lower than 2bars
            if ($currentPression <= 2) {
                
                // Add new pump
                $pumpNumber++;
                $pumpNumberWithoutBecken++;

                // Get the position (horizontal) to set the pump at
                $segmentLength = $dist - $previousDistance;
                $deltaPressionFrom = $previousPression - 2;
                $deltaPressionTo = 2 - $currentPression;                
                
                $distanceFromPrevious = $segmentLength * $deltaPressionFrom / ($deltaPressionFrom + $deltaPressionTo);
                $pumpDistance = $previousDistance + $distanceFromPrevious;
                $previousDistance = $pumpDistance;
                
                // Get the real (3D) Length
                $distance3DFromPrevious = $distance3D * $deltaPressionFrom / ($deltaPressionFrom + $deltaPressionTo);
                $pump3DDistance = $previous3DDistance + $distance3DFromPrevious;
                $previous3DDistance = $pump3DDistance;
                
                // Get pression lost pumpe to current point
                $segmentDruckVerlust = $totalDruckVerlust * $deltaPressionFrom / ($deltaPressionFrom + $deltaPressionTo);

                // Get pumpe altitude
                $pumpAltitude = $previousAltitude + ($deltaAlt * $deltaPressionFrom / ($deltaPressionFrom + $deltaPressionTo));
                $previousAltitude = $pumpAltitude;

                $currentPression = $max_druck - $segmentDruckVerlust;
                
                // Create becken associated with pumpe
                if($beckenFreq != 0 && (($pumpNumberWithoutBecken - 1) % $beckenFreq == 0)) {
                    
                    $this->createPumpe($this->UID, $pumpNumber, 4, 2, $max_druck, $pumpAltitude, $pumpDistance);                    
                }
                else {
                    // Save the pump
                    $this->createPumpe($this->UID, $pumpNumber, 1, 2, $max_druck, $pumpAltitude, $pumpDistance); 
                }

                 
                
                //$pumpNumberWithoutBecken++;

                // Save the leitung
                $deltaHoehe = $pumpAltitude - $previousPumpAltitude;
                $this->createLeitung($this->UID, $pumpNumberWithoutBecken - 1, $wassermenge, $schlauchleitung, $deltaHoehe, $previousPumpPression, 2, $previousPumpDistance, $pumpDistance, $previousPump3DDistance);

                $previousPumpPression = $max_druck;

                $previousPumpDistance = $pumpDistance;
                $previousPumpAltitude = $pumpAltitude;
                
                $previousPump3DDistance = 0.0;
            } else {

                $previousDistance = $dist;
                $previousAltitude = $altitude;
            };
            // 70 End of leitung
            if ($numberPoints == $key + 1) {
                $pumpNumber++;
                // Create end point
                $this->createPumpe($this->UID, $pumpNumber, 3, $currentPression, $currentPression, $altitude, $dist);

                // Create end leitung
                $deltaHoehe = $altitude - $previousPumpAltitude;
                $this->createLeitung($this->UID, $pumpNumberWithoutBecken, $wassermenge, $schlauchleitung, $deltaHoehe, $previousPumpPression, $currentPression, $previousPumpDistance, $dist, $previousPump3DDistance);
            }
        }

        /*
          $geomType = "LINE";
          $queryIns = "INSERT INTO webservice_map.line(objectid, wkb_geometry) VALUES('" . $this->UID . "',ST_GeomFromText('LINESTRING(" . $geomStringDB . ")',2056))";
         * */
        $WMSLayerName = "wassertransport_pumpe_temp";


        $BBbox = $x1 . "," . $y1 . "," . $x2 . "," . $y2;
        $BBboxGridsLon = $x1 . "," . $y4 . "," . $x4 . "," . $y1;
        $BBboxGridsLat = $x3 . "," . $y1 . "," . $x1 . "," . $y3;

        // Write Coords to DB
        //$resultLayerIns = $oGSIFeature->pg_read($queryIns);
        // Bilder Zusammenstellen
        // DEFINE MAGENTA AS THE TRANSPARENCY COLOR AND FILL THE IMAGE FIRST

        $WidthCoordYWidth = $Width + $CoordYWidth;
        $HeightCoordXHeight = $Height + $CoordXHeight;

        $merged_image = imagecreatetruecolor($WidthCoordYWidth, $HeightCoordXHeight);

        $transparentColor = imagecolorallocate($merged_image, 255, 255, 255);
        imagecolortransparent($merged_image, $transparentColor);
        imagefill($merged_image, 0, 0, $transparentColor);

        imagesavealpha($merged_image, true);

        // Kartenlayer Abfrage DB
        $MapfishConn = new WGWMapfishConn();
        if ($inTheme == "" or is_null($inTheme)) {
            $inTheme = "Basisinfo";
        }
        $query = "SELECT * FROM webservice_map.webservice_map_layer WHERE theme_name ='" . $inTheme . "' ORDER BY ordernr";
        $resultLayer = $MapfishConn->pg_read($query);


        while ($row = pg_fetch_assoc($resultLayer)) {

            // WMS Abfrage
            $mapUrl = $row['wmsurl'];
            $mapUrl .= "?LAYERS=";
            $mapUrl .= $row['layer'];
            $mapUrl .= "&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SRS=EPSG%3A2056&BBOX=";
            $mapUrl .= $BBbox;
            $mapUrl .= "&WIDTH=";
            $mapUrl .= $Width;
            $mapUrl .= "&HEIGHT=";
            $mapUrl .= $Height;

            // Bild zusammenstellen
            $map = func_imagecreatefrompng($mapUrl);

            imagealphablending($map, false);
            imagecopy($merged_image, $map, $CoordYWidth, 0, 0, 0, $Width, $Height);
            imagealphablending($map, true);
            imagedestroy($map); // FREE UP SOME MEMORY	
        }

        $layerUrl = $WMSUrl;
        $layerUrl .= "?LAYERS=";
        $layerUrl .= "wassertransport_leitung_temp,wassertransport_pumpe_temp";
        $layerUrl .= "&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&STYLES=&SRS=EPSG%3A2056&CRS=EPSG%3A2056&BBOX=";
        $layerUrl .= $BBbox;
        $layerUrl .= "&WIDTH=";
        $layerUrl .= $Width;
        $layerUrl .= "&HEIGHT=";
        $layerUrl .= $Height;
        $layerUrl .= "&SLD_BODY=";

        // SLD BODY
        $sld = '<?xml version="1.0" encoding="ISO-8859-1" standalone="yes"?>';
        $sld .= '<sld:StyledLayerDescriptor version="1.0.0" xmlns:sld="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink">';

        $sld .= '<sld:NamedLayer>';
        $sld .= '<sld:Name>';
        $sld .= 'wassertransport_leitung_temp';
        $sld .= '</sld:Name>';
        $sld .= '<sld:LayerFeatureConstraints>';
        $sld .= '<sld:FeatureTypeConstraint>';
        $sld .= '<ogc:Filter>';
        $sld .= '<ogc:PropertyIsEqualTo>';
        $sld .= '<ogc:PropertyName>wtp_id</ogc:PropertyName>';
        $sld .= '<ogc:Literal>' . $this->UID . '</ogc:Literal>';
        $sld .= '</ogc:PropertyIsEqualTo>';
        $sld .= '</ogc:Filter>';

        $sld .= '</sld:FeatureTypeConstraint>';
        $sld .= '</sld:LayerFeatureConstraints>';
        $sld .= '<sld:NamedStyle>';
        $sld .= '<sld:Name>classgroup1</sld:Name>';

        $sld .= '</sld:NamedStyle>';
        $sld .= '</sld:NamedLayer>';
        $sld .= '<sld:NamedLayer>';
        $sld .= '<sld:Name>';
        $sld .= 'wassertransport_pumpe_temp';
        $sld .= '</sld:Name>';
        $sld .= '<sld:LayerFeatureConstraints>';
        $sld .= '<sld:FeatureTypeConstraint>';
        $sld .= '<ogc:Filter>';
        $sld .= '<ogc:PropertyIsEqualTo>';
        $sld .= '<ogc:PropertyName>wtp_id</ogc:PropertyName>';
        $sld .= '<ogc:Literal>' . $this->UID . '</ogc:Literal>';
        $sld .= '</ogc:PropertyIsEqualTo>';
        $sld .= '</ogc:Filter>';

        $sld .= '</sld:FeatureTypeConstraint>';
        $sld .= '</sld:LayerFeatureConstraints>';
        $sld .= '<sld:NamedStyle>';
        $sld .= '<sld:Name>classgroup1</sld:Name>';

        $sld .= '</sld:NamedStyle>';
        $sld .= '</sld:NamedLayer>';


        $sld .= '</sld:StyledLayerDescriptor>';

        // Url encode
        $sld = urlencode($sld);

        $layerUrl .= $sld;

        $path = $this->tempFile("png");


        $layer = func_imagecreatefrompng($layerUrl);

        imagealphablending($layer, false);
        imagecopy($merged_image, $layer, $CoordYWidth, 0, 0, 0, $Width, $Height);
        imagealphablending($layer, true);
        imagedestroy($layer); // FREE UP SOME MEMORY


        $WMSUrl = $host_wms."/webservice_map";

// Scale and Grid
        // kürzere Kante
        $MinGrid = min(abs($x1 - $x2), abs($y1 - $y2)) / 2.01;

        if ($MinGrid > 10000) {
            $Grid = 10000;
        } else if ($MinGrid > 5000) {
            $Grid = 5000;
        } else if ($MinGrid > 2000) {
            $Grid = 2000;
        } else if ($MinGrid > 1000) {
            $Grid = 1000;
        } else if ($MinGrid > 500) {
            $Grid = 500;
        } else if ($MinGrid > 200) {
            $Grid = 200;
        } else if ($MinGrid > 100) {
            $Grid = 100;
        } else if ($MinGrid > 50) {
            $Grid = 50;
        } else if ($MinGrid > 20) {
            $Grid = 20;
        } else {
            $Grid = 10;
        }

        // X Achse

        $GridLonUrl = $WMSUrl;
        $GridLonUrl .= "?LAYERS=Grid_";
        $GridLonUrl .= $Grid;
        $GridLonUrl .= "_lon&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&SRS=EPSG%3A2056&BBOX=";
        $GridLonUrl .= $BBboxGridsLon;
        $GridLonUrl .= "&WIDTH=";
        $GridLonUrl .= $Width;
        $GridLonUrl .= "&HEIGHT=";
        $GridLonUrl .= $CoordXHeight + $Offset;

        $GridLon = func_imagecreatefrompng($GridLonUrl);
        imagealphablending($GridLon, false);
        imagecopy($merged_image, $GridLon, $CoordYWidth, $Height, 0, 0, $Width, $CoordXHeight);
        imagealphablending($GridLon, true);
        imagedestroy($GridLon); // FREE UP SOME MEMORY
        // Y Achse

        $GridLatUrl = $WMSUrl;
        $GridLatUrl .= "?LAYERS=Grid_";
        $GridLatUrl .= $Grid;
        $GridLatUrl .= "_lat&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&SRS=EPSG%3A2056&BBOX=";
        $GridLatUrl .= $BBboxGridsLat;
        $GridLatUrl .= "&WIDTH=";
        $GridLatUrl .= $CoordYWidth + $Offset;
        $GridLatUrl .= "&HEIGHT=";
        $GridLatUrl .= $Height;

        $GridLat = func_imagecreatefrompng($GridLatUrl);
        imagealphablending($GridLat, false);
        imagecopy($merged_image, $GridLat, 0, 0, $Offset, 0, $CoordYWidth, $Height);
        imagealphablending($GridLat, true);
        imagedestroy($GridLat); // FREE UP SOME MEMORY

        imagealphablending($merged_image, false);
        imagesavealpha($merged_image, true);

        imagepng($merged_image, $path);

        $this->imagePath = $path;

        // fclose($myfile);	
    }

    function tempFile($ext) {
        $nom_fichier = mt_rand() . "." . $ext; // nom du fichier a stocker
        // GR: Pfad nach Bedarf anpassen
        // $path = "/opt/apache2/fachapplikationen/webservices/tmp"; // repertoire ou stocker l'image
        $path = "/var/www/mapfish_tempo/webservice_map";

        if (is_dir($path)) {
            $path = $path . "/" . $nom_fichier;
            return $path;
        } else {
            return false;
        }
    }

    function makeBboxPoint($centreX, $centreY, $Width, $Height, $minScale) {

        $res = 6000; // 6000 px/m
        $WidthM = $Width / $res * $minScale;
        $HeightM = $Height / $res * $minScale;

        $x1_new = $centreX - ($WidthM / 2);
        $x2_new = $centreX + ($WidthM / 2);
        $y1_new = $centreY - ($HeightM / 2);
        $y2_new = $centreY + ($HeightM / 2);

        $BBboxNew = $x1_new . "," . $y1_new . "," . $x2_new . "," . $y2_new;

        $x3 = ($x1_new - ($x2_new - $x1_new) / $Width * 80);
        $y3 = $y2_new;
        $x4 = $x2_new;
        $y4 = ($y1_new - ($y2_new - $y1_new) / $Height * 40);

        return array($x1_new, $y1_new, $x2_new, $y2_new, $x3, $y3, $x4, $y4);
    }

    function makeBbox($x1, $x2, $y1, $y2, $Width, $Height, $expfaktor, $minScale) {

        //Recherche la valeur max entre le x et le y
        $long_large = ($x2 - $x1) / ($y2 - $y1);

        //Expansion de l'extent en fonction du facteur definit dans la db
        $distanceX = abs($x1 - $x2);
        $distanceY = abs($y1 - $y2);

        $centreX = $x1 + $distanceX / 2;
        $centreY = $y1 + $distanceY / 2;

        $newdistanceX = $distanceX * $expfaktor;
        $newdistanceY = $distanceY * $expfaktor;

        $res = 6000; // 6000 px/m
        $mindistanceX = $minScale * $Width / $res;
        $mindistanceY = $minScale * $Height / $res;

        if ($newdistanceX < $mindistanceX) {
            $newdistanceX = $mindistanceX;
        }
        if ($newdistanceY < $mindistanceY) {
            $newdistanceY = $mindistanceY;
        }

        $x1_new = $centreX - ($newdistanceX / 2);
        $x2_new = $centreX + ($newdistanceX / 2);

        $y1_new = $centreY - ($newdistanceY / 2);
        $y2_new = $centreY + ($newdistanceY / 2);

        /*
         * Correction d'un des axes pour respecter le rapport defini
         * pour l'affichage de l'image par le WMS
         * Si selection plus large que haute
         * coordonn?e x comme valeur de reference
         * modification de la coordonn?es Y en fonction du rapport w/h
         * Si selection plus haute que large
         * coordonn?e y comme valeur de reference
         * modification de la coordonn?es x en fonction du rapport w/h
         *
         * * */


        if ($long_large > 1) {  //selection plus large que haute
            $deltaXY_new = $Height * ($x2_new - $x1_new) / $Width;

            $y1_new = $centreY - ($deltaXY_new / 2);
            $y2_new = $centreY + ($deltaXY_new / 2);
        } else {     // selection plus haute que large
            $deltaXY_new = $Width * ($y2_new - $y1_new) / $Height;

            $x1_new = $centreX - ($deltaXY_new / 2);
            $x2_new = $centreX + ($deltaXY_new / 2);
        }

        $BBboxNew = $x1_new . "," . $y1_new . "," . $x2_new . "," . $y2_new;

        $x3 = ($x1_new - ($x2_new - $x1_new) / $Width * 80);
        $y3 = $y2_new;
        $x4 = $x2_new;
        $y4 = ($y1_new - ($y2_new - $y1_new) / $Height * 40);

        return array($x1_new, $y1_new, $x2_new, $y2_new, $x3, $y3, $x4, $y4);
    }

    /**
     * Save a pumpe in the database
     * @param integer $uid Pumpe unique id (wtp_id)
     * @param integer $pumpe_nr Pumpe number along the line (1..n)
     * @param type $typ Pumpe type (1:Pumpe, 2:Endpunkte)
     * @param type $e_bar Input Pression (in bar)
     * @param type $a_bar Output Pression (in bar)
     * @param type $alt Altitude
     * @param type $distance_from_start Distance from line start point (in meter)
     */
    function createPumpe($uid, $pumpe_nr, $typ, $e_bar, $a_bar, $alt, $distance_from_start) {

        $lineLength = $this->lineLength;

        // Hack to handle little differences from measure between swisstopo and POSTGIS (for the endpoint)
        if ($distance_from_start > $lineLength) {
            $distance_from_start = $lineLength;
        }

        $ratioDistFromStart = $distance_from_start / $lineLength;

        // Insert pump in temp table
        $sqlQuery = "INSERT INTO webservice_map.wt_pumpe (wtp_id,pumpe_nr,typ,e_bar,a_bar,alt,becken_ms,wkb_geometry) VALUES ($uid, $pumpe_nr, $typ, $e_bar, $a_bar, $alt, $this->beckenFreq, ST_LineInterpolatePoint(ST_GeomFromText('LINESTRING($this->wktLine)',2056), $ratioDistFromStart));";

        pg_query($this->dbConnection, $sqlQuery);
    }

    /**
     * Create a leitung in the database
     * @param type $uid
     * @param type $leitung_nr
     * @param type $h20maenge
     * @param type $deltaHoehe
     * @param type $e_bar
     * @param type $a_bar
     * @param type $distance_from
     * @param type $distance_to
     * @param type $previousPump3DDistance
     */
    function createLeitung($uid, $leitung_nr, $h20maenge, $schlauchleitung, $deltaHoehe, $e_bar, $a_bar, $distance_from, $distance_to, $previousPump3DDistance) {
        $lineLength = $this->lineLength;

        // Hack to handle little differences from measure between swisstopo and POSTGIS (for the endpoint)
        if ($distance_to > $lineLength) {
            $distance_to = $lineLength;
        }
        
        // Get schlauchleitung text
        $sqlschlauchleitungQuery = "SELECT * FROM feuerwehr.wt_schlauchleitung WHERE text_id LIKE '$schlauchleitung' LIMIT 1;";
        $resultschlauchleitung = pg_query($this->dbConnection, $sqlschlauchleitungQuery);
        $row = pg_fetch_assoc($resultschlauchleitung);
        $schlauchleitung_text = $row['label'];

        $ratioFrom = $distance_from / $lineLength;
        $ratioTo = $distance_to / $lineLength;

        // St_Length(ST_Line_Substring(ST_GeomFromText('LINESTRING($this->wktLine)',2056), $ratioFrom, $ratioTo)))
        // Insert leitung in temp table
        $sqlQuery = "INSERT INTO webservice_map.wt_leitung (wtp_id,leitun_nr,laenge,max_laenge,h2o_menge,schlauchleitung_id,schlauchleitung_text,dhoehe,e_bar, a_bar ,wkb_geometry, ersteller) VALUES ($uid, $leitung_nr, $previousPump3DDistance, $this->maxLaenge, $h20maenge, '$schlauchleitung', '$schlauchleitung_text',$deltaHoehe, $e_bar, $a_bar, ST_LineSubstring(ST_GeomFromText('LINESTRING($this->wktLine)',2056), $ratioFrom, $ratioTo), $this->ersteller );";

        pg_query($this->dbConnection, $sqlQuery);
    }

    /**
     * Get the total length of the linestring (the whole wassertransport)
     * @return type double
     */
    function getLineHorizontalLength() {
        // get line length
        $sqlLengthQuery = "SELECT ST_Length(ST_GeomFromText('LINESTRING($this->wktLine)',2056));";

        $resultLength = pg_query($this->dbConnection, $sqlLengthQuery);
        $row = pg_fetch_row($resultLength);
        return $row[0];
    }
    
    /**
     * Get the real length of the line
     * @param type $horizontalLength
     * @param type $deltaAlt
     * @return type
     */
    function getLineRealLength($horizontalLength, $deltaAlt) {
        return sqrt(pow($horizontalLength, 2) + pow($deltaAlt, 2));
    }
    
   
}

?>
