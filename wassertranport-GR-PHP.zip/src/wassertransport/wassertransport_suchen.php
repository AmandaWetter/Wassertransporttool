<?php

/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 * 
 *  Description: entry point for the "suchen" function.
 */

require_once("../common/WGWmakeMap.php");
require_once("../common/WGWFeatureToolExt.inc.php");

require("../_config_global/server_url_config.php" );

//====================================================================
// Input Parameter
//====================================================================
$inNrCoord = $_GET['NRCOORD'];
$inCoord = $_GET['COORD'];
$inTheme = $_GET['THEME'];

$user = $_GET['USER'];

//====================================================================
// Feature Geometrie bestimmen
//====================================================================
$Coord = explode(",", $inCoord);
$x = $Coord[0];
$y = $Coord[1];

// GR: Parameter bei Bedarf anpassen
$Width = 600;
$Height = 400;
$expfaktor = 1.5;
$minScale = 500; // 1:500
//
//
// GET the database connection

$oGSIFeature = new GSIFeatureToolExt();
$dbConnection = $oGSIFeature->_awlconn;

$queryString = "SELECT * FROM feuerwehr.wt_leitung WHERE ST_Distance(GeometryFromText('POINT(" . $x . " " . $y . ")', 2056), wkb_geometry) < 100";

$query = pg_query($dbConnection, $queryString) or die('Abfrage fehlgeschlagen');

if (pg_num_rows($query) == "0") {
    ?>

    <!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="Wassertransport">
        <title>Wassertransport: Leitung suchen</title>
    </head>

    <html>
        <body onLoad="self.resizeTo(250, 200)">
            <p style="font-family:verdana">Kein Objekt ausgewählt.<br/><br/></p>
            <button style="float: right;" onclick="self.close()">OK</button>
        </body>
    </html>

    <?php
} else {

    $result = pg_fetch_row($query);

    // Get leitung id
    $wtp_id = $result[1];

    //====================================================================
    // URL für das Profiltool erstellen
    //====================================================================
    // GR: Url anpassen

    $newUrl = $host_ws."/webservices/wassertransport/WassertransportFormular.phtml?leitung_id="; // GISZ
    //$newUrl = "http://192.168.1.62/webservices/wassertransport/WassertransportFormular.phtml?leitung_id="; // WGW
    $newUrl .= $wtp_id;
    $newUrl .= "&USER=";
    $newUrl .= $user;

    // print $newUrl;
    header("Location: $newUrl");
}
?>
