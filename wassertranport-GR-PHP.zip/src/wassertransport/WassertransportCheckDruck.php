<?php

/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 * 
 * Description: Check if the "Wassermenge" is compatible with the choosen "Schlauchleitung".
 */
session_start();

require_once("../common/WGWFeatureToolExt.inc.php");

try {

    $wassermenge = $_POST['wassermenge'];
    $schlauchleitung = $_POST['schlauchleitung'];
    
    $ersteller = $_POST['ersteller'];

    // GET the database connection
    $oGSIFeature = new GSIFeatureToolExt();
    $dbConnection = $oGSIFeature->_awlconn;

    // Get Druckverlust aus der DB Tabelle (Druckverlust Bar/100m)
    $sqlQuery = "SELECT * FROM feuerwehr.wt_druckverlust WHERE wassermenge <= $wassermenge ORDER BY wassermenge DESC LIMIT 1;";

    $resultDruckverlust = pg_query($dbConnection, $sqlQuery);
    $row = pg_fetch_assoc($resultDruckverlust);

    // Normalize druckverlust (Bar / 1m)
    $druckverlust = $row[$schlauchleitung] / 100;
    
    if($druckverlust == null) {
        throw new Exception("Wassermenge und Schlauchleitung stimmen nicht überein.");
    }
    // Send response
    $responseObj = new stdClass();
    $responseObj->message = "Die Schlauchleitung wurde geprüft.";
    $responseObj->error = false;
    $responseObj->ersteller = $ersteller;

    $response = json_encode($responseObj);

    echo $response;
} catch (Exception $ex) {

    
    $responseObj = new stdClass();
    $responseObj->message = $ex->getMessage();
    $responseObj->error = true;
    $responseObj->showDruckInfo = true;

    $response = json_encode($responseObj);

    echo $response;
}


