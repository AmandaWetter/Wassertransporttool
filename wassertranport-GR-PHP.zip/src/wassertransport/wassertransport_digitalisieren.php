<?php 

/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 * 
 * Description: entry point for the "digitalisieren" function.
 */

header('Content-Type: text/html; charset=utf-8');

require("../_config_global/server_url_config.php" );
 
//====================================================================
// Input Parameter
//====================================================================
$inNrCoord = $_GET['NRCOORD'];
$inCoord = $_GET['COORD'];
$inTheme = $_GET['THEME'];

$user = $_GET['USER'];


//====================================================================
// URL für das Profiltool erstellen
//====================================================================
// GR: Url anpassen

$newUrl = $host_ws."/webservices/wassertransport/WassertransportFormular.phtml?POLY_COUNT="; // GISZ
//$newUrl = "http://192.168.1.62/webservices/wassertransport/WassertransportFormular.phtml?POLY_COUNT="; // WGW
$newUrl .= $inNrCoord;
$newUrl .= "&COORD=";
$newUrl .= $inCoord;
$newUrl .= "&THEME=";
$newUrl .= $inTheme;
$newUrl .= "&USER=";
$newUrl .= $user;

// print $newUrl;
header("Location: $newUrl"); 

?>
