<?php

/**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: fred badel
 * Erstellt am   : 14.09.2021
 * 
 * Description: Save Wassertransport in the database. In facts it copies the Wassertransport (leitung and pumpe)
 * from the temporary tables to the productive tables. The entries on the temporary tables are deleted.
 * The productive tables are link to the WMS service
 * which display the maps.
 */

session_start();

require_once("../common/WGWFeatureToolExt.inc.php");

try {
    $leitungUID = $_SESSION["leitungUID"];

    if ($leitungUID == null) {
        throw new Exception("Sie müssen erst eine Leitung berechnen");
    }
    
    // GET the database connection
    $oGSIFeature = new GSIFeatureToolExt();
    $dbConnection = $oGSIFeature->_awlconn;
    
    $existingLeitungId = $_POST["leitungId"];
    if($existingLeitungId) {
        // DELETE EXISTING LEITUNG
        $sqlDeleteLeitung = "DELETE FROM feuerwehr.wt_leitung WHERE wtp_id = $existingLeitungId";
        pg_query($dbConnection, $sqlDeleteLeitung);
        
        // DELETE EXISTING PUMPE
        $sqlDeletePumpe = "DELETE FROM feuerwehr.wt_pumpe WHERE wtp_id = $existingLeitungId";
        pg_query($dbConnection, $sqlDeletePumpe);
    }  
    

    // COPY LEITUNG
    $sqlQueryLeitung = "INSERT INTO feuerwehr.wt_leitung
                SELECT *
                FROM webservice_map.wt_leitung
                WHERE wtp_id = $leitungUID";
    
    pg_query($dbConnection, $sqlQueryLeitung);
    
    // COPY PUMPE
    $sqlQueryPumpe = "INSERT INTO feuerwehr.wt_pumpe
                SELECT *
                FROM webservice_map.wt_pumpe
                WHERE wtp_id = $leitungUID";
    
    pg_query($dbConnection, $sqlQueryPumpe);
    
    // REMOVE OLD LEITUNG
    $sqlRemoveLeitung = "DELETE FROM webservice_map.wt_leitung
                WHERE wtp_id = $leitungUID";
    
    pg_query($dbConnection, $sqlRemoveLeitung);
    
    // REMOVE OLD PUMPE
    $sqlRemovePumpe = "DELETE FROM webservice_map.wt_pumpe
                WHERE wtp_id = $leitungUID";
    
    pg_query($dbConnection, $sqlRemovePumpe);
    
    // Remove global session leitung id
    unset($_SESSION['leitungUID']);
    
    // Send response
    $responseObj = new stdClass();
    $responseObj->message = "Die Daten wurden erfolgreich gespeichert.";
    $responseObj->error = false;
    $responseObj->leitungUID = $leitungUID;

    $response = json_encode($responseObj);
    
    echo $response;
    
} catch (Exception $ex) {

    unset($_SESSION['leitungUID']);
    $responseObj = new stdClass();
    $responseObj->message = $ex->getMessage();
    $responseObj->error = true;

    $response = json_encode($responseObj);

    echo $response;
}


