<?php
header('Content-Type: text/html; charset=utf-8');
 /**
 * Copyright 2020 GIS-Kompetenzzentrum Kanton GR
 * Erstellt durch: ol
 * Erstellt am   : 28.04.2020
 * 
 * Letzte Änderung: 28.04.2020 ol
 */

//Erweiterung damit file_get_contents https ignoriert (28.02.2020,ol)

function func_file_get_contents($url) {
    $arrContextOptions=array(
        "ssl"=>array(
                "verify_peer"=>false,
                "verify_peer_name"=>false,
            ),
        "http" => array(
                "proxy" => "tcp://proxy10.gr.ch:9090",
                "request_fulluri" => true,
            ),
        );  
    
    return file_get_contents($url, false, stream_context_create($arrContextOptions));
}

function func_imagecreatefrompng($url) {
    $fileContent = func_file_get_contents($url);	
    return imagecreatefromstring($fileContent);
}

?>
