<?php

/**
 * Copyright 2020 GIS-Kompetenzzentrum Kanton GR
 * Erstellt durch: ol
 * Erstellt am   : 28.04.2020
 * 
 * Letzte Änderung: 28.04.2020 ol
 */

$host_ws = getenv('WS_HOST_URL');

$host_map = getenv('MAP_HOST_URL');
$host_edit = getenv('EDIT_HOST_URL');

$host_wms = getenv('WMS_HOST_URL');
$host_wfs = getenv('WFS_HOST_URL');

$host_doc = getenv('DOC_HOST_URL');
 
$pg_conn_str_web = 'host=' . getenv('POSTGRES_HOST') . ' port=' . getenv('POSTGRES_PORT') . ' user=' . getenv('POSTGRES_WEB_USER') . ' password=' . getenv('POSTGRES_WEB_PASSWORD') . ' dbname=' . getenv('POSTGRES_DB');
$pg_conn_str_fme = 'host=' . getenv('POSTGRES_HOST') . ' port=' . getenv('POSTGRES_PORT') . ' user=' . getenv('POSTGRES_FME_USER') . ' password=' . getenv('POSTGRES_FME_PASSWORD') . ' dbname=' . getenv('POSTGRES_DB');
  
?>
