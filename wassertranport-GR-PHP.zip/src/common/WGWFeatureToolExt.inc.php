<?php
header('Content-Type: text/html; charset=utf-8');
/**
 * GSIFeatureTool class
 *
 * @project     CWC2
 * @revision    $Id: GSIFeatureToolExt.inc.php,v 1.6 2009/11/23 20:38:34 jack Exp $
 * @purpose     Find Location Extension class
 * @author      Reto Zahner <reto.zahner@asgal.ch>
 * @copyright
 * <b>Copyright (c) 2005, Sourcepole AG</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/**
 * $Log: GSIFeatureToolExt.inc.php,v $
 * Revision 1.6  2009/11/23 20:38:34  jack
 * - Suppression de la variable _unitFlaeche
 *
 * Revision 1.5  2009/10/20 18:10:31  jack
 * - Mise a jour de la documentation
 *
 * Revision 1.4  2009/10/20 18:07:32  jack
 * - Ajout des revisions
 *
 * Revision 1.3  2009/10/20 18:06:20  jack
 * - Ajout du parametre unit.
 */

/**
 * GSIFeatureTool extension class
 *
 */
class GSIFeatureToolExt
{
   /**
    * @var array
    */
   var $maSessionData = array();

   /**
    * @var string
    */
   var $msID = null;


   /**
    * Constructs a GSIFeatureTool Object
    *
    * @return GSIFeatureToolExt
    */

   var   $awlDbUser = "";
   var   $awlDbPwd = "";
   var   $awlDbName = "";
   var   $awlDbHost = "";
   var   $awlDbPort = "";
   var   $awlconnString = "";
   var   $awlconn = array();

      /**
 * @abstract Constructeur
 * @author jck
 */
   function __construct()
   {
        //todoGR
        require("../_config_global/server_url_config.php" );

       #$this->_awlconnString = "host=".$this->_awlDbHost." port=".$this->_awlDbPort." dbname=".$this->_awlDbName." user=".$this->_awlDbUser." password=".$this->_awlDbPwd." options='--client_encoding=UTF8'";
       $this->awlconnString = $pg_conn_str_fme." options='--client_encoding=UTF8'";

       $this->awlconn = pg_connect($this->awlconnString);  //  php5-pgsql has to be installed

   } // End of method: GSIFeatureToolExt()


   /**
 * @abstract permet la lecture d'une comande sql
 * @author jck
 * @param string $abfrage le query a appliquer
 * @return array
 */
   function pg_read($abfrage) {
      if (isset($datensatz)) unset($datensatz);
      $result = pg_exec( $this->_awlconn, $abfrage);
      for ($i=0;$i<pg_numrows($result);$i++) {
         $arr = pg_fetch_array($result,$i);
         for ($n=0;$n<pg_numfields($result);$n++) {
            $datensatz[strtoupper(pg_fieldName($result,$n))][$i] = $arr[$n];
         }
      }
      if (isset($datensatz))
            return $datensatz;
      else
            return;
   }
}

?>
