<?php
header('Content-Type: text/html; charset=utf-8');
 /**
 * Copyright 2016 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: shu
 * Erstellt am   : 19.02.2016
 * 
 * Letzte Änderung: 23.5.2016 shu
 */

require_once("WGWFeatureToolExt.inc.php"); 
require_once("WGWMapfishConn.inc.php"); 		

require_once("../_config_global/func_config.php" );	
 
function WGWmakeMap($inNrCoord, $inCoord, $inTheme, $Width, $Height, $expfaktor, $minScale) {
	// $myfile = fopen("makeMap_log.txt", "a") or die("Unable to open file!");
	// $txt = "\nStart WGWmakeMap\n";
	// fwrite($myfile, $txt);
    
	require("../_config_global/server_url_config.php" );
			
	// Session ID SID (Zufallszahl)
	$SID = number_format(mt_rand(), 0);
	// GR: Url Anpassen
	// WMS URL für Point, Line, Polygon Layer und Grids
	if (substr(gethostname(),0,4) == "opal") {
		//$inTheme = utf8_encode($inTheme);
	}
	$WMSUrl = $host_wms."/webservice_map";
	$Offset = 5;
	$CoordXHeight = 25;
	$CoordYWidth = 25;
	$CoordXWidth = $Width;
	$CoordYHeight = $Height;

	$pointarray = explode(";", $inCoord);
	
	$NrPoints = count($pointarray);
	
	// Array der Koordinaten
	$points = array();
	foreach($pointarray as $k=>$v){
        $pointarray[$k] = array_map('floatval', explode(',', $v));
        $temp = explode(',', $v);
		$points[$k]['x']  = floatval($temp[0]);
        $points[$k]['y']  = floatval($temp[1]);	
	}

	//(Erster) Punkt
	$xmin = $points[0]['x'];
	$xmax = $points[0]['x'];
	$ymin = $points[0]['y'];
	$ymax = $points[0]['y'];
	
	//Linie/ Polygon
	if ($NrPoints > 1) {
		$geomStringDB = $points[0]['x']." ".$points[0]['y'];
		for ($i = 1; $i < $NrPoints; $i++) {
			$geomStringDB .= ",".$points[$i]['x']." ".$points[$i]['y'];
			if ($xmin > $points[$i]['x']) {$xmin = $points[$i]['x'];}
			if ($xmax < $points[$i]['x']) {$xmax = $points[$i]['x'];}
			if ($ymin > $points[$i]['y']) {$ymin = $points[$i]['y'];}
			if ($ymax < $points[$i]['y']) {$ymax = $points[$i]['y'];}			
		}
		
		list($x1, $y1, $x2, $y2, $x3, $y3, $x4, $y4) = makeBbox($xmin,$xmax,$ymin,$ymax,$Width,$Height,$expfaktor,$minScale);
	}

	// Test if point
	if ($NrPoints == 1) {
		$geomType = "POINT";
		$geomStringDB = $points[0]['x']." ".$points[0]['y'];		
		$queryIns = "INSERT INTO webservice_map.point(objectid, wkb_geometry) VALUES('".$SID."',ST_GeomFromText('POINT(".$geomStringDB.")',2056))";
		list($x1, $y1, $x2, $y2, $x3, $y3, $x4, $y4) = makeBboxPoint($points[0]['x'],$points[0]['y'],$Width,$Height,$minScale);		
		$WMSLayerName = "webservice_map_Point";
	}
	
	// Test if polygon
	else if (($points[0]['x'] == $points[$NrPoints-1]['x']) && ($points[0]['y']== $points[$NrPoints-1]['y'])) {
		$geomType = "POLY";
		$queryIns = "INSERT INTO webservice_map.poly(objectid, wkb_geometry) VALUES('".$SID."',ST_GeomFromText('POLYGON((".$geomStringDB."))',2056))";		
		$WMSLayerName = "webservice_map_Poly";
	}
	
	else {
		$geomType = "LINE";	
		$queryIns = "INSERT INTO webservice_map.line(objectid, wkb_geometry) VALUES('".$SID."',ST_GeomFromText('LINESTRING(".$geomStringDB.")',2056))";		
		$WMSLayerName = "webservice_map_Line";
	}	
	
	$BBbox = $x1.",".$y1.",".$x2.",".$y2;
	$BBboxGridsLon = $x1.",".$y4.",".$x4.",".$y1;
	$BBboxGridsLat = $x3.",".$y1.",".$x1.",".$y3;

	// Write Coords to DB
	$oGSIFeature = new GSIFeatureToolExt();	
	$resultLayerIns = $oGSIFeature->pg_read($queryIns);		
	
	// Bilder Zusammenstellen
	// DEFINE MAGENTA AS THE TRANSPARENCY COLOR AND FILL THE IMAGE FIRST
	
	$WidthCoordYWidth = $Width + $CoordYWidth;
	$HeightCoordXHeight = $Height + $CoordXHeight;

	$merged_image = imagecreatetruecolor($WidthCoordYWidth, $HeightCoordXHeight);
	
	$transparentColor = imagecolorallocate($merged_image, 255, 255, 255); 
	imagecolortransparent($merged_image, $transparentColor);
	imagefill($merged_image, 0, 0, $transparentColor);

	imagesavealpha($merged_image, true);
	
	// Kartenlayer Abfrage DB
	$MapfishConn = new WGWMapfishConn();
	if ($inTheme == "" or is_null($inTheme)) {
		$inTheme = "Basisinformationen";
	}
	$query = "SELECT * FROM webservice_map.webservice_map_layer WHERE theme_name ='".$inTheme."' ORDER BY ordernr";
	$resultLayer = $MapfishConn->pg_read($query);
	
	while ($row = pg_fetch_assoc($resultLayer)) {
			
		// WMS Abfrage
		//$mapUrl = str_replace('https', 'http', $row['wmsurl']);
		$mapUrl = $row['wmsurl'];
		$mapUrl .= "?LAYERS=";		
		$mapUrl .= $row['layer'];
		$mapUrl .= "&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SRS=EPSG%3A2056&BBOX=";
		$mapUrl .= $BBbox;
		$mapUrl .= "&WIDTH=";
		$mapUrl .= $Width;
		$mapUrl .= "&HEIGHT=";
		$mapUrl .= $Height;		
				
		// Bild zusammenstellen
		$map = func_imagecreatefrompng($mapUrl);

		imagealphablending($map, false);
		imagecopy($merged_image, $map, $CoordYWidth, 0, 0, 0, $Width, $Height);
		imagealphablending($map, true);
		imagedestroy($map); // FREE UP SOME MEMORY	
					
	}

	$layerUrl = $WMSUrl;
	$layerUrl .= "?LAYERS=";
	$layerUrl .= $WMSLayerName;
	$layerUrl .= "&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&SRS=EPSG%3A2056&BBOX=";
	$layerUrl .= $BBbox;
	$layerUrl .= "&WIDTH=";
	$layerUrl .= $Width;
	$layerUrl .= "&HEIGHT=";
	$layerUrl .= $Height;
	$layerUrl .= "&SLD_BODY=";		
  
	// SLD BODY
	$sld = '<?xml version="1.0" encoding="ISO-8859-1" standalone="yes"?>';
	$sld .= '<sld:StyledLayerDescriptor version="1.0.0" xmlns:sld="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink">';
	$sld .= '<sld:NamedLayer>';
	$sld .= '<sld:Name>';
	$sld .= $WMSLayerName;
	$sld .= '</sld:Name>';
	$sld .= '<sld:UserStyle>';
	$sld .= '<sld:Name>Style</sld:Name>';
	$sld .= '<sld:FeatureTypeStyle><sld:Rule>';	
	$sld .= '<ogc:Filter><ogc:PropertyIsEqualTo>';
	$sld .= '<ogc:PropertyName>';
	$sld .= 'objectid';
	$sld .= '</ogc:PropertyName>';
	$sld .= '<ogc:Literal>';
	$sld .= $SID;
	$sld .= '</ogc:Literal>';
	$sld .= '</ogc:PropertyIsEqualTo></ogc:Filter>';
	
	if ($geomType == "POLY") {
		$sld .= '<sld:PolygonSymbolizer><sld:Stroke>';
		$sld .= '<sld:CssParameter name="stroke">#CE0F0F</sld:CssParameter>';
		$sld .= '<sld:CssParameter name="stroke-width">4</sld:CssParameter>';
		$sld .= '<sld:CssParameter name="stroke-opacity">1</sld:CssParameter>';
		$sld .= '</sld:Stroke></sld:PolygonSymbolizer>';
	}

	else if ($geomType == "LINE") {
		$sld .= '<sld:LineSymbolizer><sld:Stroke>';
		$sld .= '<sld:CssParameter name="stroke">#CE0F0F</sld:CssParameter>';
		$sld .= '<sld:CssParameter name="stroke-width">4</sld:CssParameter>';
		$sld .= '<sld:CssParameter name="stroke-opacity">1</sld:CssParameter>';
		$sld .= '</sld:Stroke></sld:LineSymbolizer>';
	}

	else if ($geomType == "POINT") {
		$sld .= '<sld:PointSymbolizer><sld:Graphic><sld:Mark>';
		$sld .= '<sld:WellKnownName>circle</sld:WellKnownName>';
		$sld .= '<sld:Fill><sld:CssParameter name="fill">#CE0F0F</sld:CssParameter></sld:Fill>';				
		$sld .= '</sld:Mark><sld:Size>16</sld:Size>';		
		$sld .= '</sld:Graphic></sld:PointSymbolizer>';
	}
	
	$sld .= '</sld:Rule></sld:FeatureTypeStyle>';
	$sld .= '</sld:UserStyle>';
	$sld .= '</sld:NamedLayer>';
	$sld .= '</sld:StyledLayerDescriptor>';
	
	// Url encode
	$sld = urlencode($sld);

	$layerUrl .= $sld;
	
	$path = tempFile("png");

	$layer = func_imagecreatefrompng($layerUrl);

	imagealphablending($layer, false);
	imagecopy($merged_image, $layer, $CoordYWidth, 0, 0, 0, $Width, $Height);
	imagealphablending($layer, true);
	imagedestroy($layer); // FREE UP SOME MEMORY
	
	// Scale and Grid
	// kürzere Kante
	$MinGrid = min(abs($x1-$x2), abs($y1-$y2))/2.01;
	
	if ($MinGrid > 10000)  {
		$Grid = 10000;
	}	
	else if ($MinGrid > 5000)  {
		$Grid = 5000;
	}
	else if ($MinGrid > 2000)  {
		$Grid = 2000;
	}
	else if ($MinGrid > 1000)  {
		$Grid = 1000;
	}
	else if ($MinGrid > 500)  {
		$Grid = 500;
	}
	else if ($MinGrid > 200)  {
		$Grid = 200;
	}
	else if ($MinGrid > 100)  {
		$Grid = 100;
	}
	else if ($MinGrid > 50)  {
		$Grid = 50;
	}
	else if ($MinGrid > 20)  {
		$Grid = 20;
	}
	else  {
		$Grid = 10;
	}
	
	// X Achse
	
	$GridLonUrl = $WMSUrl;
	$GridLonUrl .= "?LAYERS=Grid_";
	$GridLonUrl .= $Grid;
	$GridLonUrl .= "_lon&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&SRS=EPSG%3A2056&BBOX=";
	$GridLonUrl .= $BBboxGridsLon;
	$GridLonUrl .= "&WIDTH=";
	$GridLonUrl .= $Width;
	$GridLonUrl .= "&HEIGHT=";
	$GridLonUrl .= $CoordXHeight + $Offset;
	
	$GridLon = func_imagecreatefrompng($GridLonUrl);
	imagealphablending($GridLon, false);
	imagecopy($merged_image, $GridLon, $CoordYWidth, $Height, 0, 0, $Width, $CoordXHeight);
	imagealphablending($GridLon, true);
	imagedestroy($GridLon); // FREE UP SOME MEMORY

	// Y Achse

	$GridLatUrl = $WMSUrl;
	$GridLatUrl .= "?LAYERS=Grid_";
	$GridLatUrl .= $Grid;
	$GridLatUrl .= "_lat&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&SRS=EPSG%3A2056&BBOX=";
	$GridLatUrl .= $BBboxGridsLat;
	$GridLatUrl .= "&WIDTH=";
	$GridLatUrl .= $CoordYWidth + $Offset;
	$GridLatUrl .= "&HEIGHT=";
	$GridLatUrl .= $Height;
	
	$GridLat = func_imagecreatefrompng($GridLatUrl);
	imagealphablending($GridLat, false);
	imagecopy($merged_image, $GridLat, 0, 0, $Offset, 0, $CoordYWidth, $Height);
	imagealphablending($GridLat, true);
	imagedestroy($GridLat); // FREE UP SOME MEMORY

	imagealphablending($merged_image, false);
	imagesavealpha($merged_image, true);

	imagepng($merged_image, $path);

	return $path; 
	
	// fclose($myfile);	
}	

function tempFile($ext) {
 	$nom_fichier = mt_rand().".".$ext; // nom du fichier a stocker
		
		// GR: Pfad nach Bedarf anpassen
    	// $path = "/opt/apache2/fachapplikationen/webservices/tmp"; // repertoire ou stocker l'image
		$path = "/var/www/mapfish_tempo/webservice_map";
		
   	if (is_dir($path)) {
   		$path = $path."/".$nom_fichier;
		return $path;
   	}else { 	
	   	return false;
	}
}

function makeBboxPoint($centreX,$centreY,$Width,$Height,$minScale) {
	$res = 6000; // 6000 px/m
	$WidthM = $Width/$res*$minScale;
	$HeightM = $Height/$res*$minScale;
	
	$x1_new = $centreX - ($WidthM/2);
	$x2_new = $centreX + ($WidthM/2);
	$y1_new = $centreY - ($HeightM/2);
	$y2_new = $centreY + ($HeightM/2);	
	
	$BBboxNew = $x1_new.",".$y1_new.",".$x2_new.",".$y2_new;

	$x3 = ($x1_new-($x2_new-$x1_new)/$Width*80);
	$y3 = $y2_new;
	$x4 = $x2_new;
	$y4 = ($y1_new-($y2_new-$y1_new)/$Height*40);
	
	return array ($x1_new, $y1_new, $x2_new, $y2_new, $x3, $y3, $x4, $y4);
}

function makeBbox($x1,$x2,$y1,$y2,$Width,$Height,$expfaktor,$minScale) { 

	//Recherche la valeur max entre le x et le y
	$long_large = ($x2-$x1)/($y2-$y1);
	
	//Expansion de l'extent en fonction du facteur definit dans la db
	$distanceX = abs($x1-$x2);
	$distanceY = abs($y1-$y2);
		
	$centreX = $x1 + $distanceX/2;
	$centreY = $y1 + $distanceY/2;
	
	$newdistanceX = $distanceX*$expfaktor;
	$newdistanceY = $distanceY*$expfaktor;
	
	$res = 6000; // 6000 px/m
	$mindistanceX = $minScale*$Width/$res;
	$mindistanceY = $minScale*$Height/$res;
	
	if ($newdistanceX < $mindistanceX) {
		$newdistanceX = $mindistanceX;		
	}
	if ($newdistanceY < $mindistanceY) {
		$newdistanceY = $mindistanceY;	
	}	
	
	$x1_new = $centreX-($newdistanceX/2);
	$x2_new = $centreX+($newdistanceX/2);
		
	$y1_new = $centreY-($newdistanceY/2);
	$y2_new = $centreY+($newdistanceY/2);
	
	/*
	 * Correction d'un des axes pour respecter le rapport defini
	 * pour l'affichage de l'image par le WMS
	 * Si selection plus large que haute
	 * coordonn?e x comme valeur de reference
	 * modification de la coordonn?es Y en fonction du rapport w/h
	 * Si selection plus haute que large
	 * coordonn?e y comme valeur de reference
	 * modification de la coordonn?es x en fonction du rapport w/h
	 *
	 ***/
	

	if ($long_large > 1) {		//selection plus large que haute
		$deltaXY_new = $Height  * ($x2_new-$x1_new) / $Width  ;
		
		$y1_new = $centreY - ($deltaXY_new/2);
		$y2_new = $centreY + ($deltaXY_new/2);
	} 
	else { 				// selection plus haute que large
		$deltaXY_new = $Width * ($y2_new-$y1_new) / $Height;
		
		$x1_new = $centreX - ($deltaXY_new/2);
		$x2_new = $centreX + ($deltaXY_new/2);
	}
 				
	$BBboxNew = $x1_new.",".$y1_new.",".$x2_new.",".$y2_new;	
	
	$x3 = ($x1_new-($x2_new-$x1_new)/$Width*80);
	$y3 = $y2_new;
	$x4 = $x2_new;
	$y4 = ($y1_new-($y2_new-$y1_new)/$Height*40);
	
	return array ($x1_new, $y1_new, $x2_new, $y2_new, $x3, $y3, $x4, $y4);
}

?>
