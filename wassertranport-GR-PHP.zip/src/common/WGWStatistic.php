<?php
 /**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: jack
 * Erstellt am   : 14.10.2009 15:13:30
 * 
 * Revisionsinformation: $Revision: 1.3 $
 * Letzte Modifikation durch: $Author: shu $
 * am Date: $Date: 2016/08/12 $
 */
 
 
 /**
 * $Log: GSIStatistic.php,v $
 * Revision 1.1  2009/10/20 18:05:32  jack
 * - Nouvelle classe pour gerer les statistiques effectuees sur une selection spatiale
 * - Utilise avec GSIPolygonTool
 *
 * Revision 1.2  2009/08/26 21:29:02  jack
 *
 * Revision 1.3  2016/08/12 shu 
 * Funktion für Mittelwert flaechenrepraesentativ hinzugefügt
 */


class _cls_GSIStatistic {
	/** La stat a effectuer
 	 * @var string
 	 * @access private
 	 */
 	private string $_Statname;
 	
	/**
 	 * le groupe selectionne
 	 * @var array
 	 * @access private
 	 */
 	private string $_aTabValue;
 	    
 	/**
  	* @abstract le constructeur de la classe
  	* @author jck
  	* @param string $Statname
  	* @param array $aTabValue
  	*/
	function __construct($Statname, $aTabValue) {
		$this->_Statname = $Statname;
		$this->_aTabValue = $aTabValue;
	}
	
	
	/**
  	* @abstract la fonction du choix de la stat
  	* @author jck
  	*/
	function getStat(){
		
		if (strtoupper($this->_Statname) == "SUMME"){
			$StatValue =  $this->sumValue();			
		}
		elseif (strtoupper($this->_Statname) == "MAXIMUM"){
			$StatValue =  $this->maxValue();			
		}
		elseif (strtoupper($this->_Statname) == "MINIMUM"){
			$StatValue =  $this->minValue();			
		}
		elseif (strtoupper($this->_Statname) == "MITTELWERT"){
			$StatValue =  $this->meanValue();			
		}		
		elseif (strtoupper($this->_Statname) == "ANZAHL"){
			$StatValue =  $this->countValue();			
		}
		elseif (strtoupper($this->_Statname) == "FLAECHENMITTELWERT"){
			$StatValue =  $this->fmeanValue();			
		}
		return $StatValue;
	}
	
	 /**
  	* @abstract la fonction somme
  	* @author jck
  	*/
	function sumValue(){
		$summe = 0;
		$k = $this->_aTabValue;
		foreach ($k as $v2){
	    	$summe = $summe + $v2;
		}
	
		return $summe;
	}
	
	 /**
  	* @abstract la fonction max
  	* @author jck
  	*/
	function maxValue(){
	    return max($this->_aTabValue);
		
	}
	
	 /**
  	* @abstract la fonction min
  	* @author jck
  	*/
	function minValue(){
		return min($this->_aTabValue);
	}
	
	 /**
  	* @abstract la fonction moyenne
  	* @author jck
  	*/
	function meanValue(){
		return $this->sumValue()/count($this->_aTabValue);
	}
	
	 /**
  	* @abstract la fonction count
  	* @author jck
  	*/
	function countValue(){
		return count($this->_aTabValue);
	}
	
	 /**
  	* @abstract Funktion flaechenmittelwert: Mittelwert flaechenrepraesentativ
  	* @author shu
  	*/
	function fmeanValue(){

		$keys = array_keys($this->_aTabValue);
		$NrZeile = count($this->_aTabValue[$keys[0]]);
		$summe1 = 0;
		for ($zeile = 0; $zeile < $NrZeile; $zeile++) {
			$summe1 = $summe1 + $this->_aTabValue[$keys[0]][$zeile]*$this->_aTabValue[$keys[1]][$zeile];
		}
		$fsumme = array_sum($this->_aTabValue[$keys[1]]);
		$fmean = $summe1/$fsumme;
		
		return $fmean;
	}	
	
}
?>
