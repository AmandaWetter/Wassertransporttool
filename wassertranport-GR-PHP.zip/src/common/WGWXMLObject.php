<?php
header('Content-Type: text/html; charset=utf-8');
/**
 * XMLObject class
 *
 * @project     CWC2
 * @revision    $Id: XMLObject.php,v 1.13 2006/07/31 15:40:07 bartvde Exp $
 * @purpose     XMLObject class
 * @author      DM Solutions Group (assefa@dmsolutions.ca)
 * @copyright
 * <b>Copyright (c) 2002, DM Solutions Group Inc.</b>
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This class takes an XML document as a string and parses into a recursive
 * object structure.  The root XMLObject is the one you created and contains
 * no particular values.  Its children array contains the root XML objects
 * contained in the XML string passed to the constructor.
 *
 * Sample XML document:
 * <Employees version="1.0">
 *   <Employee Id="1">
 *     <Name>John</Name>
 *     <Salary Type="Annualy">20K</Salary>
 *   </Employee>
 *   <Employee Id="2">
 *     <Name>Ren</Name>
 *     <Salary Type="Weekly">2K</Salary>
 *   </Employee>
 * </MyRoot>
 *
 * Sample PHP code:
 *
 * $oXMLObj = new XMLObject( $szXMLDoc );
 *
 * $oEmployees = $oXMLObj[0];
 *
 * if ($oEmployees->version >= "1.0")
 * {
 *   foreach($Employees->children as $oEmployee)
 *   {
 *     echo $oEmployee->Id." ";
 *     echo "Name: ".$oEmployee->getNextChild("Name")->value."\n";
 *     $oSalary = $oEmployee->getNextChild("Salary");
 *     echo "Paid: ".$oSalary->value."(";
 *     echo $oSalary->Type.")";
 *   }
 * }
 * else
 *   echo "Wrong document version";
 *
 */

function xmlentities($string)
{
   return str_replace ( array ( '&', '"', "'", '<', '>', "'" ),
     array ( '&amp;', '&quot;', '&apos;' , '&lt;' , '&gt;', '&apos;' ), $string );
}

/**
 * a basic XML object.
 */
class XMLObject
{
    var $name = "XMLObject";
    var $value = "";
    var $_type = "";
    var $_cur_child_index = 0;
    var $_cur_child_name = "";
    var $children = array();
    var $node_depth = 0;
    var $tag_type = '';
    var $comment_out = false;
    var $initial_node_depth = 0;

    /**
     * constructor, pass an XML string to populate it.
     * @param szXMLDoc the XML document string to parse.
     */
    function __construct( $szXMLDoc = '', $initial_node_depth = 0 )
    {
        // set the initial node depth
        $this->initial_node_depth = $initial_node_depth;

        // process the given tag
        if ($szXMLDoc != "")
        {
            $parser = xml_parser_create('UTF-8');
            xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
            xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE,   1);
            xml_parse_into_struct($parser, $szXMLDoc, $aVals, $index);
            xml_parser_free($parser);

            $this->children = $this->parseValuesArray( $aVals );
        }
    }

    /**
     * internal function to add attributes to this object from an array
     * $attributes the array of values to add
     */
    function addAttributes( $attributes = array() )
    {
        if (is_array( $attributes ))
        {
            if (!isset($this->_attributes) || !is_array($this->_attributes))
                $this->_attributes = array();
            $this->_attributes = array_merge( $this->_attributes, $attributes );
            foreach( $attributes as $idx => $attr )
            {
                $this->{strtolower($idx)} = $attr;
            }
        }
        elseif( is_string( $attributes ) && is_string( $values ) )
        {
            $this->{strtolower($attributes)} = $values;
        }
    }

    /**
     * helper function to iterate through several children of the same
     * type name.  If szName is "" then this will return all children
     * in order.  When there are no more children of the given type
     * then the function will return "".
     * @param szName the type name to iterate through
     * @return an XMLObject for the next child or "" if not found.
     */
    function getNextChild( $szName )
    {
        // reset index if changing names
        if ($this->_cur_child_name != $szName)
        {
            $this->_cur_child_index = 0;
        }

        $this->_cur_child_name = $szName;

        if ($this->_cur_child_name == '')
        {
            if (isset($this->children[$this->_cur_child_index]))
            {
                return $this->children[$this->_cur_child_index++];
            }
            else
            {
                return ''; //at the end.
            }
        }
        else
        {
            $nChildren = count($this->children);
            for($i=$this->_cur_child_index; $i<$nChildren; $i++)
	        {
                if ($this->children[$i]->_type == $this->_cur_child_name ||
                    $this->children[$i]->name == $this->_cur_child_name)
                {
                    $this->_cur_child_index = $i+1;
                    return $this->children[$i];
                }
            }
        }

        // made it this far so failed to locate
        return '';

    }

    /**
     * recursively build an array of XMLObjects from an array returned by
     * xml_parse_into_struct
     * @param vals the values array
     * @param index the current index in the values array
     * @return an array of XMLObjects found in this vals array starting at
     * the current index.
     */
    function parseValuesArray(&$vals, $index = 0)
    {
        //children is the array of objects.  Each XML tag becomes an object
        //of type XMLChild with member variables for attributes and possibly
        //an array of children
        $GLOBALS["XMLObjectIndex"] = $index;

        $j = count($vals);

        while ($index < $j)
        {
            $k = $index++;

            // if current record is a closing tag, return the array of objects
            if ($vals[$k]['type'] == "close")
            {
                $GLOBALS["XMLObjectIndex"] = $index;
                return $this->children;
            }

            switch ($vals[$k]['type'])
            {
                // If current record is a complete tag or cdata then we create a new
                // XMLObject for it and add it to the children array
                case 'cdata':
                case 'complete':
                    $attributes = (isset($vals[$k]['attributes'])) ? $vals[$k]['attributes'] : array() ;
                    $o = new XMLObject( '', $this->initial_node_depth );
                    $o->_type = $vals[$k]['tag'];
                    $o->name = $vals[$k]['tag'];
                    $o->addAttributes( $attributes );
                    $o->value = (isset($vals[$k]['value'])) ? $vals[$k]['value'] : "";
                    $o->node_depth = $vals[$k]['level'] - 1 + $this->initial_node_depth;
                    $o->tag_type = $vals[$k]['type'];
                    array_push($this->children, $o);
                    //$index ++;
                    break;

                // If current record is an open tag
                case 'open':
                    $attributes = (isset($vals[$k]['attributes'])) ? $vals[$k]['attributes'] : array() ;
                    $o = new XMLObject( '', $this->initial_node_depth );
                    $o->_type = $vals[$k]['tag'];
                    $o->name = $vals[$k]['tag'];
                    $o->addAttributes( $attributes );
                    $o->value = (isset($vals[$k]['value'])) ? $vals[$k]['value'] : "";
                    $o->parseValuesArray($vals, $index);
                    $o->node_depth = $vals[$k]['level'] - 1 + $this->initial_node_depth;                            $o->tag_type = $vals[$k]['type'];
                    $index = $GLOBALS["XMLObjectIndex"];
                    array_push($this->children, $o);
                break;
            }
        }
        return $this->children;
    }

    /**
     * dump this object out to stdout - debugging only
     */
    function dumpObject()
    {
        echo "<PRE>";
        print_r( $this );
        echo "</PRE>";
    }

   /**
     __________________________________________________________________________
    |
    |  writeObject()
    |
    |  Postcondition:  This function reads the given node and returns it's XML
    |                  form as a string.
    |
    |  @param $oNode object - Node object to write.
    |  @param $szLineBreak string - Optional specification of the line break char to use.
    |  @param $bCommentOut boolean - Optional flag to write lines out as comments.
    |  @return string - The formatted XML output.
    |  @desc Returns formatted XML based on given Node.
    |__________________________________________________________________________

    **/
    function writeObject( $szLineBreak = "\n", $bCommentOut = false )
    {
        // init vars
        $szReturn = '';
        $szStartComment = '';
        $szEndComment = '';

        // check if node is internally flagged for commenting
        if ( $this->comment_out == true )
        {
            $bCommentOut = true;
        }

        // comment if required
        if ( $bCommentOut )
        {
            $szStartComment = '<!-- ******** REMOVED BY AUTO DOC ********';
            $szEndComment = ' -->';
        }

        // get node depth and space accordingly
        $szReturn .= $szStartComment.$this->spacePad( $this->node_depth * 2 );

        // open tag
        $szReturn .= '<'.$this->name;

        // add attributes if any
        foreach ( $this->_attributes as $key=>$value )
        {
            $szReturn .= ' '.$key.'="'.$value.'"';
        }

        // close
        $szReturn .= '>';

        if (count($this->children) > 0)
        {
            // add line break
            $szReturn .= $szEndComment.$szLineBreak;

            // check for children
            $nChildren = count( $this->children );
            for( $i=0; $i<$nChildren; $i++ )
            {
                // watch out for children not being objects
                if ( !is_object( $this->children[$i] ) )
                {
                    continue;
                }
                $szReturn .= $this->children[$i]->writeObject( $szLineBreak, $bCommentOut );

            }

            // add space pad for closing tag
            $szReturn .= $szStartComment.$this->spacePad( $this->node_depth * 2 );
        }
        else
            $szReturn .= xmlentities( $this->value );

        // add closing tag
        $szReturn .= '</'.$this->name.'>'.$szEndComment.$szLineBreak;

        // return
        return $szReturn;
    }

   /**
     __________________________________________________________________________
    |
    |  spacePad()
    |
    |  Postcondition:  This function returns the requested number of spaces as
    |                  a string.
    |
    |  @param $nCount integer - Number of spaces to return.
    |  @return string - Number of spaces as a string.
    |  @desc Returns number of spaces as a string.
    |__________________________________________________________________________

    **/
    function spacePad( $nCount )
    {
        // loop and return a string with the number of spaces
        $szReturn = '';
        for ( $i=0; $i<$nCount; $i++ )
        {
            $szReturn .= ' ';
        }

        // return
        return $szReturn;
    }

   /**
     __________________________________________________________________________
    |
    |  updateValue()
    |
    |  Postcondition:  Updates the value of the tag given in the path.
    |
    |  @param $szPath string - XML path to follow (i.e. node1/node2[3]/node3/node4[1]).
    |  @param $szValue string - Value to update to.
    |  @return boolean - true if successful, false if not.
    |  @desc Updates the XML object at the path indicated.
    |__________________________________________________________________________

    **/
    function updateValue( $szPath, $szValue )
    {
        // get node
        $oNode =& $this->getNode( $szPath );
        if ( $oNode === false )
        {
            return false;
        }

        // set the value
        $oNode->value = $szValue;

        // return success
        return true;

    // end updateValue() function
    }

   /**
     __________________________________________________________________________
    |
    |  markAsComment()
    |
    |  Postcondition:  Marks node as given in the path as commented out on next
    |                  writeObject() call.
    |
    |  @param $szPath string - XML path to follow (i.e. node1/node2[3]/node3/node4[1]).
    |  @return boolean - true if successful, false if not.
    |  @desc Marks node as commented out on next write.
    |__________________________________________________________________________

    **/
    function markAsComment( $szPath )
    {
        // get node
        if ( !($oNode =& $this->getNode( $szPath, $this ) ))
        {
            return false;
        }

        // set the value
        $oNode->comment_out = true;

        // return success
        return true;

    // end markAsComment() function
    }

   /**
     __________________________________________________________________________
    |
    |  appendNode()
    |
    |  Postcondition:  Appends the given tag to the location specified by the
    |                  path.
    |
    |  @param $szPath string - XML path to follow (i.e. node1/node2[3]/node3/node4[1]).
    |  @param $szInsertTag string - Value to append.
    |  @return boolean - true if successful, false if not.
    |  @desc Append the given tag to the current XML object at the given location.
    |__________________________________________________________________________

    **/
    function appendNode( $szPath, $szInsertTag )
    {
        // fix depth count
        if ( substr( $szPath, 0, 1 ) == '/' )
        {
            $szPath = substr( $szPath, 1 );
        }
        if ( substr( $szPath, -1 ) == '/' )
        {
            $szPath = substr( $szPath, 0, -1 );
        }
        $aszTmpDepth = explode( '/', $szPath );

        // convert the given tag to XML object
        $oInsertXML = new XMLObject( $szInsertTag, count( $aszTmpDepth ) );

        // locate node to append to
        if ( !($oNode =& $this->getNode( $szPath, $this ) ) )
        {
            return false;
        }

        // append the object to the child array of the given path
        array_push( $oNode->children, $oInsertXML->children[0] );

        // return success
        return true;

    // end appendNode() function
    }


   /**
     __________________________________________________________________________
    |
    |  getNode()
    |
    |  Postcondition:  This function returns a pointer to the node
    |                  specified in the path.
    |
    |  @param $szPath string - XML path to follow (i.e. node1/node2[3]/node3/node4[1]).
    |  @param $oXML object - Optioinal XML object if not supplied then use current.
    |  @return mixed - Pointer to node or false if not found.
    |  @desc Returns pointer to requested node.
    |__________________________________________________________________________

    **/
    function &getNode( $szPath )//, $oXML='' )
    {
        // check if XML has been passed
        /*
        if ( $oXML == '' )
        {
            $oXML =& $this;
        }
        */

        // strip leading and trailing "/"
        if ( substr( $szPath, 0, 1 ) == '/' )
        {
            $szPath = substr( $szPath, 1 );
        }
        if ( substr( $szPath, -1 ) == '/' )
        {
            $szPath = substr( $szPath, 0, -1 );
        }

        // get the first node info from the path
        $szRemainingPath = '';
        $nPos = strpos( $szPath, '/' );
        if ( $nPos !== false )
        {
            $szRemainingPath = substr( $szPath, $nPos + 1 );
            $szPath = substr( $szPath, 0, $nPos );
        }

        //ignore [] on names
        $aTmpPath = explode( "[", $szPath );
        $szPath = $aTmpPath[0];

        // check if the current node matches
        if ( $this->name == $szPath )
        {
            // match - check for more path
            if ( strlen( $szRemainingPath ) > 0 )
            {
                $aszRemainingPath = explode( "/", $szRemainingPath );

                // check the string for occurance
                $aTmpPath = explode( '[', $aszRemainingPath[0] );

                // set variables
                if ( isset( $aTmpPath[1] ) && substr( $aTmpPath[1], -1 ) == ']' )
                {
                    $nOccurance = intval( substr( $aTmpPath[1], 0, -1 ) );
                }
                else
                {
                    $nOccurance = 1;
                }

                $nChildren = count($this->children);
                //quick sanity check, cannot ask for an index higher
                //than the number of children

                if ($nChildren < $nOccurance)
                    return false;

                for( $i=0; $i<$nChildren; $i++ )
                {
                    $oResult =& $this->children[$i]->getNode( $szRemainingPath );
                    if (is_object($oResult))
                    {
                        $nOccurance = $nOccurance - 1;
                        if ($nOccurance == 0)
                        {
                            return $oResult;
                        }
                    }
                }
                return false;
            }
            return $this;
        }
        return false;

    // end of getNode() function
    }

   /**
     __________________________________________________________________________
    |
    |  getNodeCount()
    |
    |  Postcondition:  This function counts the number of nodes for the end node
    |                  of the given path.
    |
    |  @param $szPath string - XML path to follow (i.e. node1/node2[3]/node3/node4[1]).
    |  @param $oXML object - Optioinal XML object if not supplied then use current.
    |  @return integer - Node count.
    |  @desc Returns node count for end node.
    |__________________________________________________________________________

    **/
    function getNodeCount( $szPath, $oXML = '' )
    {
        // check if the XML object was given
        if ( $oXML == '' )
        {
            $oXML = $this;
        }

        // loop and count the nodes
        $nCount = 1;
        while( $nCount < 999 )
        {
            // get next node
            $oNode =& $oXML->getNode( $szPath.'['.$nCount.']');
            if ( $oNode === false )
            {
                return $nCount - 1;
            }

            // increment counter
            $nCount++;
        }

        // if not returned by now then something is wrong
        return 0;

    // end getNodeCount() function
    }

   /**
     __________________________________________________________________________
    |
    |  getIndexByVal()
    |
    |  Postcondition:  This function returns the node index of the given path
    |                  for the given value.
    |
    |  @param $szPath string - XML path to follow (i.e. node1/node2[3]/node3/node4[1]).
    |  @param $szValue string - value to search for.
    |  @param $szSubTag string - Optional subtag to check the value of.
    |  @return mixed - Index if successful, false if not.
    |  @desc Returns node index for given value.
    |__________________________________________________________________________

    **/
    function getIndexByVal( $szPath, $szValue, $szSubTag='' )
    {
        // remove trailing '/'
        if ( substr( $szPath, -1 ) == '/' )
        {
            $szPath = substr( $szPath, 0, -1 );
        }

        // check for trailing ']'
        if ( substr( $szPath, -1 ) == ']' )
        {
            // invalid path, we're looking for the index so it can't be given
            return false;
        }

        // loop through all nodes
        $nCount = $this->getNodeCount( $szPath );
        for ( $i=0; $i<$nCount; $i++ )
        {
            // build the next node path
            if ( $szSubTag == '' )
            {
                $szNodePath = $szPath.'['.($i + 1).']';
            }
            else
            {
                $szNodePath = $szPath.'['.($i + 1).']/'.$szSubTag;
            }

            // get next node
            if ( !($oNode =& $this->getNode( $szNodePath ) ))
            {
                return false;
            }

            // check value
            if ( strtolower( $oNode->value ) == strtolower( $szValue ) )
            {
                return $i + 1;
            }
        }

        // if not returned by now then not found
        return false;

    // end getIndexByVal() function
    }
}
?>
