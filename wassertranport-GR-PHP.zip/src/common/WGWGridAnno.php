<?php
header('Content-Type: text/html; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: x-requested-with"); 
 /**
 * Copyright 2016 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: shu
 * Erstellt am   : 24.05.2016
 * 
 * Letzte Änderung: 7.6.2016 shu
 */

//====================================================================
// Parameter
//====================================================================

// Resize Factor for Width and Height of the Images (Pixel Resolution)
$Factor = 8;

$Width = $_GET['WIDTH']*$Factor;
$Height = $_GET['HEIGHT']*$Factor;

$CenterX = $_GET['CX'];
$CenterY = $_GET['CY'];

$CoordXHeight = $_GET['COORDXHEIGHT']*$Factor;
$CoordYWidth = $_GET['COORDYWIDTH']*$Factor;
$scale = $_GET['SCALE'];
$Offset = $_GET['OFFSET'];
$GridLatImage = $_GET['GRIDLAT'];
$GridLonImage = $_GET['GRIDLON'];		

require_once("../_config_global/func_config.php" );	

//====================================================================
// Start WGWGridAnno
//====================================================================

$mon_image = WGWGridAnno($CenterX, $CenterY, $Width, $Height, $Offset, $CoordXHeight, $CoordYWidth,$Factor,$scale,$GridLatImage,$GridLonImage);

function WGWGridAnno($CenterX, $CenterY, $Width, $Height, $Offset, $CoordXHeight, $CoordYWidth,$Factor,$scale,$GridLatImage,$GridLonImage) {

	// GR Anpassen: WMS URL für Grids
    
	require("../_config_global/server_url_config.php" );
    
	$WMSUrl = $host_wms."/webservice_map_mf";
	// GR Anpassen: Verzeichnis für die Koordinatenbeschriftungen
	$MapPath = "/var/www/mapfish_tempo/webservice_map/";
		
	list($x1, $y1, $x2, $y2, $x3, $y3, $x4, $y4) = makeBbox($CenterX,$CenterY,$Width,$Height,$CoordXHeight,$CoordYWidth,$Factor,$scale);

	// $BBbox = $x1.",".$y1.",".$x2.",".$y2;
	$BBboxGridsLon = $x1.",".$y4.",".$x4.",".$y1;
	$BBboxGridsLat = $x3.",".$y1.",".$x1.",".$y3;
	
	// Scale and Grid
	// kürzere Kante
	$MinGrid = min(abs($x1-$x2), abs($y1-$y2))/2.01; // 3.4 für kleiner Beschriftungs-Abstände
	
	if ($MinGrid > 10000)  {
		$Grid = 10000;
	}	
	else if ($MinGrid > 5000)  {
		$Grid = 5000;
	}
	else if ($MinGrid > 2000)  {
		$Grid = 2000;
	}
	else if ($MinGrid > 1000)  {
		$Grid = 1000;
	}
	else if ($MinGrid > 500)  {
		$Grid = 500;
	}
	else if ($MinGrid > 200)  {
		$Grid = 200;
	}
	else if ($MinGrid > 100)  {
		$Grid = 100;
	}
	else if ($MinGrid > 50)  {
		$Grid = 50;
	}
	else if ($MinGrid > 20)  {
		$Grid = 20;
	}
	else  {
		$Grid = 10;
	}
	
	// X Achse
	$GridLonUrl = $WMSUrl;
	$GridLonUrl .= "?LAYERS=Grid_";
	$GridLonUrl .= $Grid;
	$GridLonUrl .= "_lon&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&SRS=EPSG%3A2056&BBOX=";
	$GridLonUrl .= $BBboxGridsLon;
	$GridLonUrl .= "&WIDTH=";
	$GridLonUrl .= $Width;
	$GridLonUrl .= "&HEIGHT=";
	$GridLonUrl .= $CoordXHeight + $Offset;

	$ImageLon = imagecreatetruecolor($Width, $CoordXHeight);	
	$backgroundColor = imagecolorallocate($ImageLon, 255, 255, 255); 
	imagefill($ImageLon, 0, 0, $backgroundColor);	
	$GridLon = func_imagecreatefrompng($GridLonUrl);	
	imagecopy($ImageLon, $GridLon, 0, 0, 0, 0, $Width, $CoordXHeight);	
	$pathlon = $MapPath.$GridLonImage;	
	imagepng($ImageLon, $pathlon);
	imagedestroy($GridLon); // FREE UP SOME MEMORY 
	imagedestroy($ImageLon); // FREE UP SOME MEMORY
	
	// Y Achse
	$GridLatUrl = $WMSUrl;
	$GridLatUrl .= "?LAYERS=Grid_";
	$GridLatUrl .= $Grid;
	$GridLatUrl .= "_lat&FORMAT=image%2Fpng&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&SRS=EPSG%3A2056&BBOX=";
	$GridLatUrl .= $BBboxGridsLat;
	$GridLatUrl .= "&WIDTH=";
	$GridLatUrl .= $CoordYWidth + $Offset;
	$GridLatUrl .= "&HEIGHT=";
	$GridLatUrl .= $Height;
	
	$ImageLat = imagecreatetruecolor($CoordYWidth, $Height);	
	$backgroundColor = imagecolorallocate($ImageLat, 255, 255, 255); 
	imagefill($ImageLat, 0, 0, $backgroundColor);	
	$GridLat = func_imagecreatefrompng($GridLatUrl);
	imagecopy($ImageLat, $GridLat, 0, 0, $Offset, 0, $CoordYWidth, $Height);	
	$pathlat = $MapPath.$GridLatImage;	
	imagepng($ImageLat, $pathlat);
	imagedestroy($GridLat); // FREE UP SOME MEMORY
	imagedestroy($ImageLat); // FREE UP SOME MEMORY

	return 1; 	
}

function makeBbox($CenterX,$CenterY,$Width,$Height,$CoordXHeight,$CoordYWidth,$Factor,$scale) {
	$newdistanceX = $Width/$Factor*$scale*0.0003527;
	$newdistanceY = $Height/$Factor*$scale*0.0003528;
	
	$x1 = $CenterX-($newdistanceX/2);
	$x2 = $CenterX+($newdistanceX/2);
		
	$y1 = $CenterY-($newdistanceY/2);
	$y2 = $CenterY+($newdistanceY/2);
	
	$x3 = ($x1-$newdistanceX/$Width*$CoordYWidth);
	$y3 = $y2;
	$x4 = $x2;
	$y4 = ($y1-$newdistanceY/$Height*$CoordXHeight);
	
	return array ($x1, $y1, $x2, $y2, $x3, $y3, $x4, $y4);
}

?>
