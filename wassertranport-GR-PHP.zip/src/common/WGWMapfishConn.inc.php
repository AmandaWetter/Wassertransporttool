<?php
header('Content-Type: text/html; charset=utf-8');
/**
 * WGWMapfishConn class
 *
 * $Log: WGWMapfishConn.inc.php,v $
 * Revision 1.1  2016/05/10 shu
 * - GSIFeatureToolExt adaptiert für Mapfish Datenbank Zugang
 **/

/**
 * WGWMapfishConn extension class
 *
 */
class WGWMapfishConn
{
	/**
	 * @var array
	 */
	// var $maSessionData = array();

	/**
	 * @var string
	 */
	// var $msID = null;


	/**
	 * Constructs a WGWMapfishConn Object
	 *
	 * @return WGWMapfishConn
	 */

	// var   $awlDbUser = "";
	// var   $awlDbPwd = "";
	// var   $awlDbName = "";
	// var   $awlDbHost = "";
	// var   $awlDbPort = "";
	// var   $awlconnString = "";
	// var   $awlconn = array();

		/**
 * @abstract Constructeur
 * @author jck
 */
	function __construct()
	{
        //todoGR
        require("../_config_global/server_url_config.php" );

	    #$this->_awlDbUser = "mapfish";
        #$this->_awlDbPwd = "mapfish";
        #$this->_awlDbName = "mapfish";
        #$this->_awlDbHost = $host_master_pg;
        #$this->_awlDbPort = "5432";
		
	    #$this->_awlconnString = "host=".$this->_awlDbHost." port=".$this->_awlDbPort." dbname=".$this->_awlDbName." user=".$this->_awlDbUser." password=".$this->_awlDbPwd." options='--client_encoding=UTF8'";
	    $this->_awlconnString = $pg_conn_str_web." options='--client_encoding=UTF8'";

	    $this->_awlconn = pg_connect($this->_awlconnString);  //  php5-pgsql has to be installed

	} // End of method: WGWMapfishConn()


 /**
 * @param string $abfrage le query a appliquer
 * @return array
 */
         function pg_read($abfrage) {
		  if (isset($datensatz)) unset($datensatz);
		  $result = pg_exec( $this->_awlconn, $abfrage);
		  if (isset($result))
		  		return $result;			
		  else
		  		return;
		}
}

?>
