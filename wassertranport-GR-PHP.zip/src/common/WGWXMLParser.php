<?php
header('Content-Type: text/html; charset=utf-8');
 /**
 * Copyright 2009 WaterGisWeb AG, Donnerbuelweg 41, CH-3012 Bern
 * Erstellt durch: jack
 * Erstellt am   : 18.05.2009 
 * 
 * Revisionsinformation: $Revision: 1.7 $
 * Letzte Modifikation durch: $Author: phanuel $
 * am Date: $Date: 2010/09/02 14:33:36 $
 */
 
  
require_once("WGWXMLObject.php" );

class GSIParser
{
	var $maVals = array();
    var $maThemes = array();
    var $maThemeIndex = array();
    var $maLayers = array();
	
	function __construct( $szThemeFile )
    {
    	 
/* ==================================================================== */
/*      Used implode(file instead of file_get_contents which is only    */
/*      defined if php >= 4.3.0.                                        */
/* ==================================================================== */
    
   
     if (function_exists("file_get_contents"))
        {
            $szXML = file_get_contents( $szThemeFile );
        }
        else
        {
            $szXML = implode('',file($szThemeFile));
        }   
        $this->Parse( $szXML );   
    }
   
    function Parse( $szXML )
    {
        $oXML = new XMLObject( $szXML );
        $oThemes = $oXML->getNextChild( "themes" );

        $oGlobal = $oThemes->getNextChild( "global" );

        $this->maGlobals["gThemeBold"] = "false";
        $this->maGlobals["gThemeFont"] = "";
        $this->maGlobals["gThemeFontSize"] = "";
        $this->maGlobals["gThemeIcon"] = "";
        $this->maGlobals["gThemeExtendAbstract"] = "false";
        $this->maGlobals["gThemeExtendContext"] = "false";
        $this->maGlobals["gThemeExtraLayers"] = -1;

        $this->maGlobals["gGroupBold"] = "false";
        $this->maGlobals["gGroupFont"] = "";
        $this->maGlobals["gGroupFontSize"] = "";
        $this->maGlobals["gGroupIcon"] = "";
        $this->maGlobals["gGroupExtendAbstract"] = "false";
        $this->maGlobals["gGroupVisible"] = "true";

        if ($oGlobal != "")
        {
            $ogTheme = $oGlobal->getNextChild( "themeParams" );
            $this->maGlobals["gThemeBold"] = (isset($ogTheme->bold)) ? $ogTheme->bold : $this->maGlobals["gThemeBold"];
            $this->maGlobals["gThemeFont"] = (isset($ogTheme->font)) ? $ogTheme->font : $this->maGlobals["gThemeFont"];
            $this->maGlobals["gThemeFontSize"] = (isset($ogTheme->fontsize)) ? $ogTheme->fontsize : $this->maGlobals["gThemeFontSize"];
            $this->maGlobals["gThemeIcon"] = (isset($ogTheme->icon)) ? $ogTheme->icon : $this->maGlobals["gThemeIcon"];
            $this->maGlobals["gThemeExtendAbstract"] = (isset($ogTheme->extendabstract)) ? $ogTheme->extendabstract : $this->maGlobals["gThemeExtendAbstract"];
            $this->maGlobals["gThemeExtendContext"] = (isset($ogTheme->extendcontext)) ? $ogTheme->extendcontext : $this->maGlobals["gThemeExtendContext"];

            $ogGroup = $oGlobal->getNextChild( "groupParams" );
            $this->maGlobals["gGroupBold"] = (isset($ogGroup->bold)) ? $ogGroup->bold : $this->maGlobals["gGroupBold"];
            $this->maGlobals["gGroupFont"] = (isset($ogGroup->font)) ? $ogGroup->font : $this->maGlobals["gGroupFont"];
            $this->maGlobals["gGroupFontSize"] = (isset($ogGroup->fontsize)) ? $ogGroup->fontsize : $this->maGlobals["gGroupFontSize"];
            $this->maGlobals["gGroupIcon"] = (isset($ogGroup->icon)) ? $ogGroup->icon : $this->maGlobals["gGroupIcon"];
            $this->maGlobals["gGroupExtendAbstract"] = (isset($ogGroup->extendabstract)) ? $ogGroup->extendabstract : $this->maGlobals["gGroupExtendAbstract"];
            $this->maGlobals["gGroupVisible"] = (isset($ogGroup->visible)) ? $ogGroup->visible : $this->maGlobals["gGroupVisible"];
        }

        $this->maVals = array();

        while( ($oTheme = $oThemes->getNextChild( "" )) != "" )
        {
            if ($oTheme->_type == "theme")
            {
                if (!isset($this->maVals["theme"]))
                    $this->maVals["theme"] = array();

                $aTheme = array();

                $aTheme["theme_type"] = isset($oTheme->type) ? $oTheme->type : "checkbox";
                $aTheme["theme_abstract"] = isset($oTheme->abstract) ? $oTheme->abstract : "";
                $aTheme["theme_name"] = isset($oTheme->name) ? $oTheme->name : "theme";
                $aTheme["theme_bold"] = isset($oTheme->bold) ? $oTheme->bold : $this->maGlobals["gThemeBold"];
                $aTheme["theme_font"] = isset($oTheme->font) ? $oTheme->font : $this->maGlobals["gThemeFont"];
                $aTheme["theme_fontsize"] = isset($oTheme->fontsize) ? $oTheme->fontsize : $this->maGlobals["gThemeFontSize"];
                $aTheme["theme_icon"] = isset($oTheme->icon) ? $oTheme->icon : $this->maGlobals["gThemeIcon"];
                $aTheme["theme_extendabstract"] = isset($oTheme->extendabstract) ? $oTheme->extendabstract : $this->maGlobals["gThemeExtendAbstract"];
                $aTheme["theme_extralayers"] = isset($oTheme->extralayers) ? $oTheme->extralayers : "false";
                $aTheme["theme_numlayers"] = "0";
                //calculated values
                $aTheme["theme_id"] = count( $this->maVals["theme"] );
                $aTheme["theme_input"] = "";
                $aTheme["theme_url"] = "";

                if ($aTheme["theme_extralayers"] == "true")
                 {
                 $this->maGlobals["gThemeExtraLayers"] = $aTheme["theme_id"];
                }
                array_push( $this->maVals["theme"], $aTheme );

                $this->maThemes[ $aTheme["theme_name"] ] = array();
                array_push( $this->maThemeIndex, $aTheme["theme_name"] );

                while ( ($oGroup = $oTheme->getNextChild("")) != "" )
                {
                    if ($oGroup->_type == "group")
                    {
                        if (!isset($this->maVals["group"]))
                            $this->maVals["group"] = array();

                        $aGroup = array();

                        $aGroup["group_abstract"] = isset($oGroup->abstract) ? $oGroup->abstract : "";
                        $aGroup["group_field"] = isset($oGroup->field) ? $oGroup->field : "";
                        $aGroup["group_fieldalias"] = isset($oGroup->fieldalias) ? $oGroup->fieldalias : "";
                        $aGroup["group_fieldabstract"] = isset($oGroup->fieldabstract) ? $oGroup->fieldabstract : "";
                        $aGroup["group_type"] = isset($oGroup->type) ? $oGroup->type : "";
                        $aGroup["group_name"] = isset($oGroup->name) ? $oGroup->name : "group";
                        $aGroup["group_tocname"] = isset($oGroup->tocname) ? $oGroup->tocname : "";
                        $aGroup["group_dbname"] = isset($oGroup->dbname) ? $oGroup->dbname : "";
                        $aGroup["group_identify"] = isset($oGroup->identify) ? $oGroup->identify : "";
                        $aGroup["group_statistic"] = isset($oGroup->statistic) ? $oGroup->statistic : "";
                        $aGroup["group_unit"] = isset($oGroup->unit) ? $oGroup->unit : "";
                        $aGroup["group_mode"] = isset($oGroup->mode) ? $oGroup->mode : "";
                        $aGroup["group_title"] = isset($oGroup->title) ? $oGroup->title : "";			
                        $aGroup["group_egrid"] = isset($oGroup->egrid) ? $oGroup->egrid : "";
                        
  /*                      $aGroup["group_bold"] = isset($oGroup->bold) ? $oGroup->bold : $this->maGlobals["gGroupBold"];
                        $aGroup["group_font"] = isset($oGroup->font) ? $oGroup->font : $this->maGlobals["gGroupFont"];
                        $aGroup["group_fontsize"] = isset($oGroup->fontsize) ? $oGroup->fontsize : $this->maGlobals["gGroupFontSize"];
                        $aGroup["group_icon"] = isset($oGroup->icon) ? $oGroup->icon : $this->maGlobals["gGroupIcon"];
                        $aGroup["group_extendabstract"] = isset($oGroup->extendabstract) ? $oGroup->extendabstract : $this->maGlobals["gGroupExtendAbstract"];
                        $aGroup["group_visible"] = isset($oGroup->visible) ? $oGroup->visible : $this->maGlobals["gGroupVisible"];
*/
                        //calculated values
                        $aGroup["group_id"] = count( $this->maVals["group"] );
                        $aGroup["group_theme_id"] = $aTheme["theme_id"];
                        $aGroup["group_input"] = "";
                        $aGroup["group_url"] = "";
                        
                        $aGroup["group_sort"] = Array();
                        while ( ($oSort = $oGroup->getNextChild("")) != "" )
                        {
                            if ($oSort->_type == "sort" && isset( $oSort->field ))
                            {   
                                $aSort = array();

                                $aSort["field"] = isset($oSort->field) ? $oSort->field : "";
                                $aSort["mode"] = isset($oSort->mode) ? $oSort->mode : "";
                                $aSort["showfield"] = isset($oSort->showfield) ? $oSort->showfield : "";
                                $aSort["abstract"] = isset($oSort->abstract) ? $oSort->abstract : "";
                                
                                array_push( $aGroup["group_sort"], $aSort );
                            }
                        }

                        array_push( $this->maVals["group"], $aGroup );

                        $this->maThemes[ $aTheme["theme_name"] ][ $aGroup["group_name"] ] = array();

                        while ( ($oLayer = $oGroup->getNextChild("")) != "" )
                        {
                            if ($oLayer->_type == "layer" && isset( $oLayer->name ))
                            {
                                $this->maThemes[ $aTheme["theme_name"] ][ $aGroup["group_name"] ][] = $oLayer->name;
                                $this->maLayers[ $oLayer->name ] = array();
                                $this->maLayers[ $oLayer->name ]['theme'] = $aTheme["theme_name"];
                                $this->maLayers[ $oLayer->name ]['group'] = $aGroup["group_name"];

                            }
                        }
                    }
                }
            }
        }
        $this->mnThemes = count($this->maThemes);
   /*      echo "nombre de themes : ".$this->GetNumberOfThemes()."<br>";
       echo "Index : ".$this->GetThemeIndex( "Selected" )."<br>";
       echo "Attribute : ".$this->GetThemeAttribute("Selected","theme_abstract");
         
    //  $this->getSelectedLayer();
	  
	  echo "<br>getGroupeIndex : ". $this->GetGroupIndex("Result", "Kanton");
	  echo "<br>getGroupeAttribut : ".$this->GetGroupAttribute("Result", "Kanton", "group_abstract");
	  
	  echo  $this->getLayername("Selected", "Group_Selected");
	 */
	 
	  }

    function GetLayername ($themeName, $groupName){
    	
    	$aGroups = $this->GetGroups($themeName);
    	foreach ($aGroups as $szGroupName => $aLayersInGroup){
    	 	if ( $szGroupName == $groupName){
	    		foreach( $aLayersInGroup as $szLayerName ) {
                    return $szLayerName;
                 }
            }
       }
    }
    
    function GetNumberOfThemes()
    {
        return $this->mnThemes;
    }

    function GetTheme($i)
    {
        if ($i>=0 && $i<$this->mnThemes)
        {
            return $this->maThemeIndex[$i];
        }
    }

    function GetThemeIndex( $szTheme )
    {
        return array_search( $szTheme, $this->maThemeIndex );
    }

    function GetThemeAttribute( $szTheme, $szAttribute )
    {
        $idx = $this->GetThemeIndex( $szTheme );
        if( isset( $this->maVals["theme"][$idx][$szAttribute] ) )
            return $this->maVals["theme"][$idx][$szAttribute];
        else
            return "";
    }

    function GetGroupIndex( $szTheme, $szGroup )
    {
        $theme_id = $this->GetThemeIndex( $szTheme );

        foreach( $this->maVals["group"] as $idx => $aGroup )
        {
            if ($aGroup["group_theme_id"] == $theme_id && $aGroup["group_name"] == $szGroup )
                return $idx;
        }
    }

    function GetGroupAttribute( $szTheme, $szGroup, $szAttribute )
    {
        $idx = $this->GetGroupIndex( $szTheme, $szGroup );
        if( isset( $this->maVals["group"][$idx][$szAttribute] ) )
            return $this->maVals["group"][$idx][$szAttribute];
        else
            return "";
    }
    
    function GetGroupSort( $szTheme, $szGroup )
    {
        $idx = $this->GetGroupIndex( $szTheme, $szGroup );
        if (count($this->maVals["group"][$idx]['group_sort']) > 0) {
            return $this->maVals["group"][$idx]['group_sort'];
        }
        
        return "";
    }

    function GetNumGroups($szTheme)
    {
        if (isset($this->maThemes[trim($szTheme)]))
        {
            $idx = $this->GetThemeIndex( $szTheme );
            if ($this->maVals["theme"][$idx]["theme_type"] == "radio")
                $result = 1;
            else
                $result = count($this->maThemes[trim($szTheme)]);
            return $result;
        }

        return 0;
    }

    function GetGroups( $szTheme )
    {
        if (isset($this->maThemes[trim($szTheme)]))
            return $this->maThemes[trim($szTheme)];
        else
            return array();
    }
    
    
    }
    
     /**
 * $Log: GSIXMLParser.php,v $
 * Revision 1.7  2010/09/02 14:33:36  phanuel
 * modif masque résultat pour Liegenschaft: ajout E-GRID , ne pas afficher" Wert"
 *
 * Revision 1.6  2010/02/26 10:31:34  jack
 * - Changement fieldname en fieldalias
 *
 * Revision 1.5  2010/02/23 07:48:34  jack
 * - Definition du nom de la colonne avec une entree dans le xmlfile (fieldname)
 *
 * Revision 1.4  2009/11/23 20:39:26  jack
 * - Nouvelle propriété unit dans le layer de selection
 *
 * Revision 1.3  2009/10/20 18:04:19  jack
 * *** empty log message ***
 *
 * Revision 1.2  2009/08/26 21:29:02  jack
 * - Nouvelle gestion du manager
 * - Definition du xmlfile dans la widget
 *
 * Revision 1.1  2009/06/23 20:12:46  jack
 * - Widget de type GSI (GebietSInformation) :
 * - Selection dans une base postgresql depuis un polygone (GSIPolygonTool) ou un point déterminant un Feature d'une table (GSIFeatureTool).
 * 22-06-09
 * jck
 *
 */
?>
